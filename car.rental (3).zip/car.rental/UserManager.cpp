#include "UserManager.h"
#include <iostream>
#include <fstream>

using namespace std;

// سازنده کلاس
UserManager::UserManager(string path) : filePath(path) {
    head = nullptr;
    // کلاس HashTable خودش در سازنده آرایه را مقداردهی اولیه می‌کند
    loadFromFile();
}

// نمایش لیست بدهکاران (استفاده از لیست پیوندی برای پیمایش کل)
void UserManager::showDefaulters() {
    User* temp = head;
    cout << "\n--- Users with Outstanding Debt ---\n";
    bool found = false;
    while (temp) {
        if (temp->balance_due > 0) {
            cout << "User: " << temp->username << " | Debt: " << temp->balance_due << " Toman" << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No debtors found." << endl;
}

void UserManager::saveToFile() {
    ofstream outFile(filePath);
    if (!outFile) return;
    User* temp = head;
    while (temp != nullptr) {
        // استفاده از فرمت مشخص برای جلوگیری از خطا در خواندن
        outFile << temp->username << " " << temp->passwordHash << " " 
                << temp->role << " " << temp->balance_due << " " << temp->history << endl;
        temp = temp->next;
    }
    outFile.close();
}

void UserManager::loadFromFile() {
    ifstream inFile(filePath);
    if (!inFile) return;
    
    string un, r, hist;
    unsigned long long ph;
    double bal;
    
    // خواندن دقیق فیلدها
    while (inFile >> un >> ph >> r >> bal >> hist) {
        User* newUser = new User(un, "", r);
        newUser->passwordHash = ph;
        newUser->balance_due = bal;
        newUser->history = hist;
        
        newUser->next = head;
        head = newUser;
        userHash.insert(un, newUser);
    }
    inFile.close();
}

// ثبت نام کاربر جدید
bool UserManager::signUp(string username, string password, string role) {
    // استفاده از جستجوی سریع هش برای چک کردن تکراری نبودن
    if (findUser(username) != nullptr) {
        cout << "Error: Username already exists!" << endl;
        return false;
    }
    
    // ایجاد کاربر جدید (هش کردن پسورد داخل سازنده User انجام می‌شود)
    User* newUser = new User(username, password, role);
    
    // ۱. اضافه کردن به لیست پیوندی
    newUser->next = head;
    head = newUser;
    
    // ۲. اضافه کردن به جدول هش
    userHash.insert(username, newUser);
    
    saveToFile();
    cout << "Registration successful for " << username << endl;
    return true;
}

// جستجوی کاربر (بهینه شده با HashTable)
User* UserManager::findUser(string username) {
    // به جای پیمایش لیست (O(n))، از جدول هش استفاده می‌کنیم (O(1))
    return userHash.search(username);
}

// ورود به سیستم
User* UserManager::login(string username, string password) {
    User* user = findUser(username);
    
    // هش کردن پسورد ورودی و مقایسه با هش موجود در سیستم
    if (user != nullptr && user->passwordHash == hashPassword(password)) {
        return user;
    }
    return nullptr;
}

// اعمال جریمه
void UserManager::applyFine(string username, double amount) {
    User* u = findUser(username);
    if (u) {
        u->balance_due += amount;
        saveToFile();
        cout << "Fine of " << amount << " applied to " << username << endl;
    } else {
        cout << "User not found!" << endl;
    }
}