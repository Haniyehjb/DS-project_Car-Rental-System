#ifndef RESERVATION_H
#define RESERVATION_H

#include <string>
#include "Date.h"

using namespace std;

class Reservation {
public:
    string username;
    string carModel;
    Date startDate;
    Date endDate;
    bool isActive;
    Reservation* next;

    Reservation(string u, string c, Date start, Date end) 
        : username(u), carModel(c), startDate(start), endDate(end), isActive(true), next(nullptr) {}
};

#endif