#include <iostream>
#include <string>
#include <limits>
#include <cstdlib>

// ترتیب هدرها برای جلوگیری از تداخل کلمه byte با ویندوز
#include "UserManager.h"
#include "FleetManager.h"
#include "Date.h"

// هدر کمکی برای پسورد مخفی (باید بعد از بقیه باشد)
#include "ConsoleHelper.h" 

using namespace std; 

// تابع پاک کردن صفحه
void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

// تابع ایجاد وقفه برای خواندن پیام‌ها
void pause() {
    cout << "\nPress Enter to continue...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

// --- منوی مدیریت و کارکنان ---
void showManagerMenu(UserManager& uM, FleetManager& fM) {
    int choice;
    while (true) {
        clearScreen();
        cout << "====================================" << endl;
        cout << "       ADMIN PANEL (STAFF)          " << endl;
        cout << "====================================" << endl;
        cout << "1. Add New Car to Fleet\n";
        cout << "2. View All Active Rentals\n";
        cout << "3. Apply Manual Fine / Repair Cost\n";
        cout << "4. Block / Unblock User\n";
        cout << "5. Export Revenue Report (CSV)\n";
        cout << "6. Confirm Car Pickup (Set to RENTED)\n";
        cout << "7. Logout\n";
        cout << "------------------------------------" << endl;
        cout << "Enter Choice: ";
        
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        if (choice == 1) {
            string m; double p;
            cout << "Enter Car Model: "; cin >> m;
            cout << "Enter Rental Price (per min): "; cin >> p;
            fM.addCar(m, p);
            pause();
        } else if (choice == 2) {
            fM.displayRentedCars();
            pause();
        } else if (choice == 3) {
            string u; double cost;
            cout << "Target Username: "; cin >> u;
            cout << "Fine/Repair Amount: "; cin >> cost;
            uM.applyFine(u, cost);
            pause();
        } else if (choice == 4) {
            string u; cout << "Username to Toggle: "; cin >> u;
            uM.toggleBlockStatus(u);
            pause();
        } else if (choice == 5) {
            fM.exportRevenueCSV();
            pause();
        } else if (choice == 6) {
            string m; cout << "Enter Car Model being picked up: "; cin >> m;
            fM.confirmPickup(m);
            pause();
        } else if (choice == 7) {
            break;
        }
    }
}

// --- منوی مشتریان ---
void showCustomerMenu(User* user, UserManager& uM, FleetManager& fM) {
    int choice;
    while (true) {
        clearScreen();
        cout << "====================================" << endl;
        cout << "   WELCOME, " << user->username << endl;
        cout << "   Current Debt: $" << user->balance_due << endl;
        cout << "====================================" << endl;
        cout << "1. View Fleet & Return Times\n";
        cout << "2. Reserve a Car\n";
        cout << "3. Return Car (Check-in)\n";
        cout << "4. Pay Outstanding Balance\n";
        cout << "5. Logout\n";
        cout << "------------------------------------" << endl;
        cout << "Enter Choice: ";
        cin >> choice;

        if (choice == 1) {
            fM.displayAllCars();
            pause();
        } else if (choice == 2) {
            if (user->balance_due > 1000) {
                cout << "\n[!] ACCESS DENIED: Debt too high ($" << user->balance_due << ").\n";
            } else {
                fM.displayAllCars();
                string model; cout << "\nEnter Model to Reserve: "; cin >> model;
                Car* car = fM.findCar(model);
                if (!car) {
                    cout << "Error: Car not found.\n";
                } else if (car->status != AVAILABLE) {
                    cout << "Car is " << (car->status == MAINTENANCE ? "in repair." : "rented.") << "\nJoin waitlist? (y/n): ";
                    char j; cin >> j;
                    if (j == 'y' || j == 'Y') {
                        car->waitList.push(user->username, 1);
                        cout << "Added to waitlist.\n";
                    }
                } else {
                    int s, e;
                    cout << "Start Minute: "; cin >> s;
                    cout << "End Minute: "; cin >> e;
                    if (fM.addReservation(user->username, model, Date(s), Date(e))) {
                        double cost = (e - s > 0 ? e - s : 1) * car->pricePerDay;
                        user->balance_due += cost;
                        uM.saveToFile();
                        cout << "Success! Estimated Cost: $" << cost << endl;
                    } else {
                        cout << "\n[!] CONFLICT ERROR: Time slot taken.\n";
                    }
                }
            }
            pause();
        } else if (choice == 3) {
            string m; int cur;
            cout << "Enter Model: "; cin >> m;
            cout << "Current Minute: "; cin >> cur;
            fM.checkIn(m, Date(cur), uM);
            pause();
        } else if (choice == 4) {
            double amt;
            cout << "Your debt: $" << user->balance_due << "\nEnter amount to pay: "; cin >> amt;
            uM.payFine(user->username, amt);
            pause();
        } else if (choice == 5) {
            break;
        }
    }
}

// --- تابع اصلی ---
int main() {
    UserManager uM("users.txt");
    FleetManager fM("cars.txt");
    int choice;

    while (true) {
        clearScreen();
        cout << "====================================" << endl;
        cout << "      CAR RENTAL SYSTEM V2.0        " << endl;
        cout << "====================================" << endl;
        cout << "1. Sign Up\n2. User Login\n3. Admin Login\n4. Exit\n";
        cout << "------------------------------------" << endl;
        cout << "Choice: ";
        
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        if (choice == 1) {
            string u, p;
            cout << "Username: "; cin >> u;
            // پاک کردن اینتر باقی‌مانده در بافر برای اینکه پسورد ستاره‌دار درست عمل کند
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout << "Password (Stars): "; 
            p = getHiddenPassword();
            
            if (uM.signUp(u, p, "Customer")) cout << "Success!\n";
            else cout << "Username exists.\n";
            pause();
        } else if (choice == 2) {
            string u, p;
            cout << "Username: "; cin >> u;
            // پاک کردن بافر
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout << "Password (Stars): "; 
            p = getHiddenPassword();
            
            User* user = uM.login(u, p);
            if (user && !user->isBlocked) {
                showCustomerMenu(user, uM, fM); 
            }
            else if (user) {
                cout << "Account BLOCKED.\n";
                pause();
            }
            else {
                cout << "Invalid Login.\n";
                pause();
            }
        } else if (choice == 3) {
            string u, p;
            cout << "Admin ID: "; cin >> u;
            // پاک کردن بافر
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout << "Admin Password: "; 
            p = getHiddenPassword();
            
            if (u == "admin" && p == "admin123") {
                showManagerMenu(uM, fM);
            }
            else { 
                cout << "Invalid Admin.\n"; 
                pause(); 
            }
        } else if (choice == 4) {
            break;
        }
    }
    return 0;
}