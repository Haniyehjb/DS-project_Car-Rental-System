#include <iostream>
#include <string>
#include "UserManager.h"
#include "FleetManager.h"
#include "Date.h"

using namespace std;

const string USER_FILE = "users.txt";
const string CAR_FILE = "cars.txt";

// --- MANAGER MENU ---
void showManagerMenu(UserManager& uManager, FleetManager& fManager) {
    int choice;
    while (true) {
        cout << "\n--- MANAGER PANEL ---\n1. Add Car\n2. Maintenance\n3. Process Waitlist\n4. Revenue CSV\n5. Defaulters\n6. Logout\nChoice: ";
        cin >> choice;
        if (choice == 1) {
            string m; double p;
            cout << "Model: "; cin >> m;
            cout << "Price/Day: "; cin >> p;
            fManager.addCar(m, p);
        } else if (choice == 2) {
            string m; cout << "Model: "; cin >> m;
            fManager.setMaintenance(m);
        } else if (choice == 3) {
            string m; cout << "Model to process: "; cin >> m;
            fManager.processQueue(m);
        } else if (choice == 4) {
            fManager.exportRevenueCSV();
        } else if (choice == 5) {
            uManager.showDefaulters();
        } else if (choice == 6) break;
    }
}

void showCustomerMenu(User* user, UserManager& manager, FleetManager& fleet) {
    int choice;
    while (true) {
        cout << "\n--- CUSTOMER MENU ---\n";
        cout << "1. View History\n";
        cout << "2. Reserve a Car\n";
        cout << "3. Pay Fines\n";
        cout << "4. Logout\n";
        cout << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            cout << "\n--- Your History ---\n";
            if (user->history == "No_History" || user->history == "") cout << "No history yet." << endl;
            else cout << "History: " << user->history << endl;
        } 
        else if (choice == 2) {
            // ۱. نمایش لیست دقیقاً همین‌جا
            fleet.displayAllCars(); 

            string model;
            cout << "\nEnter car model name: "; 
            cin >> model;

            Car* car = fleet.findCar(model);
            if (!car) {
                cout << "Error: Car not found!" << endl;
                continue;
            }

            if (car->status != AVAILABLE) {
                cout << "Car is busy (" << (car->status == MAINTENANCE ? "Maintenance" : "Rented") << ")." << endl;
                char join;
                cout << "Join waitlist? (y/n): "; cin >> join;
                if (join == 'y' || join == 'Y') {
                    car->waitList.push(user->username, 1);
                    cout << "Added to waitlist." << endl;
                }
            } 
            else {
                int d, m, y;
                cout << "Start Date (d m y): "; cin >> d >> m >> y;
                Date start(d, m, y);
                cout << "End Date (d m y): "; cin >> d >> m >> y;
                Date end(d, m, y);

                if (fleet.addReservation(user->username, model, start, end)) {
                    // ۲. اصلاح تاریخچه (حذف No_History)
                    if (user->history == "No_History" || user->history == "") {
                        user->history = model;
                    } else {
                        user->history += "_" + model;
                    }
                    manager.saveToFile();
                    cout << "SUCCESS! Car reserved." << endl;
                } else {
                    cout << "Error: Date conflict." << endl;
                }
            }
        }
        else if (choice == 3) {
            user->balance_due = 0;
            manager.saveToFile();
            cout << "Fines cleared.\n";
        }
        else if (choice == 4) {
            break;
        }
    }
}

// --- MAIN ---
int main() {
    UserManager system(USER_FILE);
    FleetManager fleet(CAR_FILE);
    int choice;
    string u, p;

    while (true) {
        cout << "\n--- CAR RENTAL SYSTEM ---\n1. Sign Up\n2. Customer Login\n3. Admin Login\n4. Exit\nChoice: ";
        cin >> choice;
        
        if (choice == 1) {
            cout << "Username: "; cin >> u;
            cout << "Password: "; cin >> p;
            system.signUp(u, p, "Customer");
        } 
        else if (choice == 2) {
            cout << "Username: "; cin >> u;
            cout << "Password: "; cin >> p;
            User* loggedIn = system.login(u, p);
            if (loggedIn) {
                showCustomerMenu(loggedIn, system, fleet);
            } else {
                cout << "Invalid username or password!" << endl;
            }
        } 
        else if (choice == 3) {
            cout << "Admin Username: "; cin >> u;
            cout << "Admin Password: "; cin >> p;
            // در دنیای واقعی ادمین هم باید در فایل باشد، اما فعلاً طبق کد شما استاتیک است
            if (u == "admin" && p == "admin123") {
                showManagerMenu(system, fleet);
            } else {
                cout << "Access Denied!" << endl;
            }
        } 
        else if (choice == 4) {
            break;
        }
    }
    return 0;
}