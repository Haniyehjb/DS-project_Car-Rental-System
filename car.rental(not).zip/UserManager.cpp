#include "UserManager.h"
#include <iostream>
#include <fstream>

using namespace std;

UserManager::UserManager(string path) : filePath(path), head(nullptr) {
    loadFromFile();
}

// Fixed: Unified hashing logic to match User.cpp
string UserManager::hashPassword(string password) {
    string hashed = password;
    for (int i = 0; i < hashed.length(); i++) {
        hashed[i] = hashed[i] + 3; 
    }
    return hashed;
}

bool UserManager::signUp(string username, string password, string role) {
    if (findUser(username)) {
        return false; // User already exists
    }
    
    // Hash before creating the User object
    string h_pass = hashPassword(password);
    User* newUser = new User(username, h_pass, role);
    
    // Add to Linked List
    newUser->next = head;
    head = newUser;
    
    // Add to Hash Table for fast login
    userHash.insert(username, newUser);
    
    saveToFile();
    return true;
}

User* UserManager::login(string username, string password) {
    User* user = findUser(username);
    // Compare the hash of the input with the stored hash
    if (user && user->passwordHash == hashPassword(password)) {
        return user;
    }
    return nullptr;
}

User* UserManager::findUser(string username) {
    return userHash.search(username); // O(1) average time lookup
}

void UserManager::applyFine(string username, double amount) {
    User* u = findUser(username);
    if (u) {
        u->balance_due += amount;
        saveToFile();
        cout << "Fine of " << amount << " applied to " << username << ". New balance: " << u->balance_due << endl;
    } else {
        cout << "User not found." << endl;
    }
}

void UserManager::toggleBlockStatus(string username) {
    User* u = findUser(username);
    if (u) {
        u->isBlocked = !u->isBlocked;
        saveToFile();
        cout << "User " << username << (u->isBlocked ? " is now BLOCKED." : " is now UNBLOCKED.") << endl;
    } else {
        cout << "User not found." << endl;
    }
}

void UserManager::saveToFile() {
    ofstream out(filePath);
    if (!out) return;

    User* temp = head;
    while (temp) {
        // Save all critical fields including the block status (1 for true, 0 for false)
        out << temp->username << " " 
            << temp->passwordHash << " " 
            << temp->role << " " 
            << temp->balance_due << " " 
            << (temp->isBlocked ? 1 : 0) << endl;
        temp = temp->next;
    }
    out.close();
}

void UserManager::loadFromFile() {
    ifstream in(filePath);
    if (!in) return;

    string un, pw, r;
    double bal;
    int blocked;

    while (in >> un >> pw >> r >> bal >> blocked) {
        User* newUser = new User(un, pw, r);
        newUser->balance_due = bal;
        newUser->isBlocked = (blocked == 1);
        
        // Rebuild the Linked List and Hash Table from file data
        newUser->next = head;
        head = newUser;
        userHash.insert(un, newUser);
    }
    in.close();
}