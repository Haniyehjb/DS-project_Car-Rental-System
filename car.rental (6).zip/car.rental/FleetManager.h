#ifndef FLEET_MANAGER_H
#define FLEET_MANAGER_H

#include "Car.h"
#include "AVLTree.h"
#include "Reservation.h"
#include "User.h"
#include <string>
#include <vector>

using namespace std;

class UserManager;

class FleetManager {
public:
    Car* head;
    Car* tail;
    AVLTree carIndex;
    Reservation* resHead; 
    double totalRevenue;
    string filePath;

    FleetManager(string path);
    void addCar(string model, double price);
    void setMaintenance(string model);
    Car* findCar(string model);
    
    // متدهای رزرو و صف
    bool isCarAvailable(string model, Date start, Date end);
    bool addReservation(string user, string carModel, Date start, Date end);
    void processQueue(string model);
    
    void saveCars();
    void loadCars();
    void exportRevenueCSV(); // متد جدید برای گزارش‌گیری
    void displayAllCars();
    Date getReturnDate(string model);
    bool extendRental(string username, string carModel, int extraDays, UserManager& uManager);
    void returnCar(string username, string carModel, Date actualDate, UserManager& uManager);
};

#endif