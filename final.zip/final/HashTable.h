#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <string>
#include <vector>
#include "User.h" 

using namespace std;

struct HashNode {
    string key;
    User* userPtr;
    HashNode* next;

    HashNode(string k, User* u) : key(k), userPtr(u), next(nullptr) {}
};

class HashTable {
private:
    static const int TABLE_SIZE = 211; 
    HashNode* table[TABLE_SIZE];
    

    int hashFunction(string key) {
    unsigned long hash = 5381;
    for (char ch : key) {
        hash = ((hash << 5) + hash) + ch;
    }
    return hash % TABLE_SIZE;
}

public:
    HashTable() {
        for (int i = 0; i < TABLE_SIZE; i++) table[i] = nullptr;
    }

    void insert(string key, User* u) {
        int index = hashFunction(key);
        HashNode* newNode = new HashNode(key, u);
        newNode->next = table[index];
        table[index] = newNode;
    }

    User* search(string key) {
        int index = hashFunction(key);
        HashNode* entry = table[index];
        while (entry) {
            if (entry->key == key) return entry->userPtr;
            entry = entry->next;
        }
        return nullptr;
    }
    ~HashTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        HashNode* entry = table[i];
        while (entry != nullptr) {
            HashNode* prev = entry;
            entry = entry->next;
            delete prev;
        }
        table[i] = nullptr;
    }
}
};

#endif