#include "FleetManager.h"
#include "UserManager.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <fstream>

#define RESET       "\033[0m"
#define LIME_GREEN  "\033[92m"

using namespace std;

FleetManager::FleetManager(string path) : filePath(path) {
    head = tail = nullptr;
    resHead = nullptr;
    totalRevenue = 0.0;
    loadCars();
    loadReservations();
}

void FleetManager::addCar(string model, double price) {
    Car* newCar = new Car(model, price);
    if (!head) {
        head = tail = newCar;
    } else {
        tail->next = newCar;
        newCar->prev = tail;
        tail = newCar;
    }
    carIndex.insert(model, newCar); 
    saveCars();
}

Car* FleetManager::findCar(string model) {
    
    return carIndex.search(model); 
}

bool FleetManager::isCarAvailable(string model, Date start, Date end) {
    Reservation* temp = resHead;
    while (temp) {
        if (temp->carModel == model && temp->isActive) {
            
            if (start.totalMinutes < temp->endDate.totalMinutes && 
                end.totalMinutes > temp->startDate.totalMinutes) {
                return false;
            }
        }
        temp = temp->next;
    }
    return true;
}

bool FleetManager::addReservation(string user, string carModel, Date start, Date end) {
    if (!isCarAvailable(carModel, start, end)) return false;

    Car* c = findCar(carModel);
    if (c) {
        Reservation* newRes = new Reservation(user, carModel, start, end);
        newRes->next = resHead;
        resHead = newRes;

        c->status = RENTED;
        c->rentedBy = user;
        saveCars();
        saveReservations(); 
        return true;
    }
    return false;
}

void FleetManager::displayAllCars() {
    if (!head) {
        cout << "No cars available in the fleet.\n";
        return;
    }

    Car* temp = head;
    cout << "\n------------------ FLEET STATUS ------------------\n";
    while (temp) {
        cout << "Model: " << temp->model << " | Price: $" << temp->pricePerDay;
        
        if (temp->status == AVAILABLE) {
            cout << " | Status: [Available]";
        } 
        else if (temp->status == MAINTENANCE) {
            cout << " | Status: [Maintenance]";
        } 
        else if (temp->status == RENTED) {
            cout << " | Status: [Rented]";
            
            
            Reservation* res = resHead;
            bool found = false;
            while (res) {
                if (res->carModel == temp->model && res->isActive) {
                    cout << " | Return Time: Minute " << res->endDate.totalMinutes;
                    found = true;
                    break;
                }
                res = res->next;
            }
            if (!found) cout << " | Return Time: Pending...";
        }
        cout << endl;
        temp = temp->next;
    }
    cout << "--------------------------------------------------\n";
}

void FleetManager::processQueue(string model) {
    Car* c = findCar(model);
    if (c && !c->waitList.isEmpty()) {
        WaitRequest nextReq = c->waitList.pop(); 
        string nextUser = nextReq.username;     
        c->status = RENTED;
        c->rentedBy = nextUser;
        cout << "Queue Alert: Car " << model << " assigned to " << nextUser << endl;
        saveCars();
    }
}

void FleetManager::processReturn(string model, int actualMinutes, char health, UserManager& uManager) {
    Car* c = findCar(model);
    if (!c || c->status != RENTED) {
        cout << "Error: Car not found or not rented.\n";
        return;
    }

    if (actualMinutes > 1) {
        double fine = (actualMinutes - 1) * (c->pricePerDay * 0.5);
        uManager.applyFine(c->rentedBy, fine);
        totalRevenue += fine;
        cout << "Late Return Fine: " << fine << endl;
    }

    if (health == 'n' || health == 'N') {
        c->status = MAINTENANCE;
        cout << "Car moved to MAINTENANCE.\n";
    } else {
        c->status = AVAILABLE;
        c->rentedBy = "None";
        cout << "Car returned successfully.\n";
        processQueue(model);
    }
    saveCars();
}

void FleetManager::displayRentedCars() {
    Car* temp = head;
    bool found = false;
    cout << "\n--- ADMIN: ACTIVE RENTALS ---\n";
    while (temp) {
        if (temp->status == RENTED) {
            cout << "Model: " << temp->model << " | User: " << temp->rentedBy << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No active rentals found.\n";
}

void FleetManager::saveCars() {
    
    ofstream outFile(filePath);
    if (!outFile.is_open()) {
        cout << "Error: Could not open " << filePath << " for saving!" << endl;
        return;
    }

    Car* temp = head;
    while (temp) {
        
        string renter = (temp->rentedBy.empty() || temp->rentedBy == "") ? "None" : temp->rentedBy;

        
        outFile << temp->model << " "
            << temp->pricePerDay << " "
            << static_cast<int>(temp->status) << " "
            << renter << endl;

        temp = temp->next;
    }
    outFile.close();
}

void FleetManager::loadCars() {
    ifstream inFile(filePath);
    if (!inFile) return;

    string m, rb;
    double p;
    int s;

    
    while (inFile >> m >> p >> s >> rb) {
        Car* newCar = new Car(m, p);
        newCar->status = static_cast<CarStatus>(s);

       
        if (rb == "None") {
            newCar->rentedBy = "";
        }
        else {
            newCar->rentedBy = rb;
        }

        
        if (!head) {
            head = tail = newCar;
        }
        else {
            tail->next = newCar;
            newCar->prev = tail;
            tail = newCar;
        }
        
        carIndex.insert(m, newCar);
    }
    inFile.close();
}

void FleetManager::setMaintenance(string model) {
    Car* c = findCar(model);
    if (c) {
        c->status = MAINTENANCE;
        saveCars();
    }
}

bool FleetManager::extendRental(string username, string carModel, int extraDays, UserManager& uManager) {
    Car* c = findCar(carModel);
    if (c && c->rentedBy == username && c->waitList.isEmpty()) {
        double cost = extraDays * c->pricePerDay;
        uManager.applyFine(username, cost);
        totalRevenue += cost;
        saveCars();
        return true;
    }
    return false;
}
void FleetManager::checkIn(string model, Date actualDate, UserManager& uManager) {
    Car* c = findCar(model);
    
    if (!c || c->status != RENTED) return;

    Reservation* res = resHead;
    while (res) {
        
        if (res->carModel == model && res->isActive) {

            
            int duration = actualDate.totalMinutes - res->startDate.totalMinutes;
            if (duration <= 0) duration = 1; 

            
            double rentalCost = duration * c->pricePerDay;

            
            double lateFine = 0;
            if (actualDate.totalMinutes > res->endDate.totalMinutes) {
                int extra = actualDate.totalMinutes - res->endDate.totalMinutes;
                
                lateFine = extra * c->pricePerDay * 1.5;
            }

            
            uManager.applyFine(res->username, rentalCost + lateFine);

            
            totalRevenue += (rentalCost + lateFine);

            
            res->isActive = false;      
            c->status = AVAILABLE;      
            c->rentedBy = "None";       

            
            saveCars();
            saveReservations();
            processQueue(model); 

            
            cout << "\n--------------------------" << endl;
            cout << "Rental Summary for: " << model << endl;
            cout << "Duration: " << duration << " day(s)" << endl;
            cout << "Base Rental Cost: $" << rentalCost << endl;

            if (lateFine > 0) {
                int extraDays = actualDate.totalMinutes - res->endDate.totalMinutes;
                cout << "Late Return: " << extraDays << " extra day(s)" << endl;
                cout << "Late Fine (1.5x rate): $" << lateFine << endl;
            }

            cout << "Total Charged to " << res->username << ": $" << (rentalCost + lateFine) << endl;
            cout << "--------------------------" << endl;

            return; 
        }
        res = res->next;
    }
}
void FleetManager::saveReservations() {
    ofstream out("reservations.txt");
    Reservation* temp = resHead;
    while (temp) {
        
        out << temp->username << " " 
            << temp->carModel << " " 
            << temp->startDate.totalMinutes << " " 
            << temp->endDate.totalMinutes << " " 
            << (temp->isActive ? 1 : 0) << endl;
        temp = temp->next;
    }
    out.close();
}

void FleetManager::loadReservations() {
    ifstream in("reservations.txt");
    if (!in) return;

    string un, model;
    int startMin, endMin, active;
    while (in >> un >> model >> startMin >> endMin >> active) {
        Reservation* newRes = new Reservation(un, model, Date(startMin), Date(endMin));
        newRes->isActive = (active == 1);
        
        
        newRes->next = resHead;
        resHead = newRes;
    }
    in.close();
}
FleetManager::~FleetManager() {
    
    Car* currentCar = head;
    while (currentCar) {
        Car* next = currentCar->next;
        delete currentCar;
        currentCar = next;
    }

    
    Reservation* currentRes = resHead;
    while (currentRes) {
        Reservation* next = currentRes->next;
        delete currentRes;
        currentRes = next;
    }
}
void FleetManager::confirmPickup(string model) {
    Car* c = findCar(model);
    if (c) {
        if (c->status == MAINTENANCE) {
            cout << "Error: This car is under maintenance and cannot be rented.\n";
        } else {
            c->status = RENTED; 
            saveCars();
            cout << "Success: Rental started. Car status updated to RENTED.\n";
        }
    } else {
        cout << "Error: Car model not found.\n";
    }
}


void FleetManager::saveToFile() {
    
    saveCars();
    cout << "All changes successfully synchronized with database." << endl;
}
void FleetManager::exportRevenueCSV() {
    ofstream csvFile("revenue_report.csv");

   
    csvFile << "--- RENTAL TRANSACTIONS ---" << endl;
    csvFile << "Type,User,Car Model,Duration(Days),Status,Base Cost" << endl;

    Reservation* temp = resHead;
    double rentalTotal = 0;

    while (temp) {
        Car* c = findCar(temp->carModel);
        double dailyPrice = (c) ? c->pricePerDay : 0;

       
        int duration = temp->endDate.totalMinutes - temp->startDate.totalMinutes;
        if (duration <= 0) duration = 1;

        
        double cost = duration * dailyPrice;

        csvFile << "Rental,"
            << temp->username << ","
            << temp->carModel << ","
            << duration << "," 
            << (temp->isActive ? "Active" : "Completed") << ","
            << fixed << setprecision(2) << cost << endl;

        
        if (!temp->isActive) rentalTotal += cost;
        temp = temp->next;
    }

    
    csvFile << endl << "--- ADDITIONAL CHARGES (Fines & Repairs) ---" << endl;
    csvFile << "Description,Amount" << endl;

    
    double otherRevenue = totalRevenue - rentalTotal;
    if (otherRevenue < 0) otherRevenue = 0;

    csvFile << "Total Fines and Damages (Manual/Late)," << otherRevenue << endl;

    
    csvFile << endl << "--- FINAL SUMMARY ---" << endl;
    csvFile << "Total Rental Income:,$" << rentalTotal << endl;
    csvFile << "Total Other Income:,$" << otherRevenue << endl;
    csvFile << "GRAND TOTAL REVENUE:,$" << totalRevenue << endl;

    csvFile.close();

    
    cout << "Complete report (Rentals + Fines) exported to revenue_report.csv" << endl;
}