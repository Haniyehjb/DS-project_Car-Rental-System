#ifndef DATE_H
#define DATE_H

#include <iostream>
using namespace std;

struct Date {
    int day, month, year;

    Date(int d = 1, int m = 1, int y = 2024) : day(d), month(m), year(y) {}

    int toDays() const {
        return (year * 365) + (month * 30) + day;
    }

    bool operator<(const Date& other) const { return toDays() < other.toDays(); }
    bool operator>(const Date& other) const { return toDays() > other.toDays(); }
    bool operator<=(const Date& other) const { return toDays() <= other.toDays(); }
    bool operator>=(const Date& other) const { return toDays() >= other.toDays(); }
    bool operator==(const Date& other) const { return toDays() == other.toDays(); }

    void print() const {
        cout << day << "/" << month << "/" << year;
    }
};

#endif