#ifndef PRIORITY_QUEUE_H
#define PRIORITY_QUEUE_H

#include <string>
#include <vector>
#include <iostream>

using namespace std;

struct WaitRequest {
    string username;
    int priority; // هرچه عدد کمتر باشد، اولویت بیشتر است (زمان ثبت)

    WaitRequest(string u, int p) : username(u), priority(p) {}
};

class PriorityQueue {
private:
    vector<WaitRequest> heap;

    void heapifyUp(int index) {
        while (index > 0 && heap[index].priority < heap[(index - 1) / 2].priority) {
            swap(heap[index], heap[(index - 1) / 2]);
            index = (index - 1) / 2;
        }
    }

    void heapifyDown(int index) {
        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < heap.size() && heap[left].priority < heap[smallest].priority)
            smallest = left;
        if (right < heap.size() && heap[right].priority < heap[smallest].priority)
            smallest = right;

        if (smallest != index) {
            swap(heap[index], heap[smallest]);
            heapifyDown(smallest);
        }
    }

public:
    void push(string user, int p) {
        heap.push_back(WaitRequest(user, p));
        heapifyUp(heap.size() - 1);
    }

    string pop() {
        if (heap.empty()) return "";
        string topUser = heap[0].username;
        heap[0] = heap.back();
        heap.pop_back();
        heapifyDown(0);
        return topUser;
    }

    bool isEmpty() { return heap.empty(); }
};

#endif