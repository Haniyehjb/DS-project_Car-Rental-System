#include <iostream>
#include <string>
#include "UserManager.h"
#include "FleetManager.h"
#include "Date.h"

using namespace std;

const string USER_FILE = "users.txt";
const string CAR_FILE = "cars.txt";

void showManagerMenu(UserManager& uManager, FleetManager& fManager) {
    int choice;
    while (true) {
        cout << "\n--- MANAGER PANEL ---\n1. Add Car\n2. Maintenance\n3. Process Waitlist\n4. Revenue CSV\n5. Defaulters\n6. Logout\nChoice: ";
        cin >> choice;
        if (choice == 1) {
            string m; double p;
            cout << "Model: "; cin >> m;
            cout << "Price/Day: "; cin >> p;
            fManager.addCar(m, p);
        } else if (choice == 2) {
            string m; cout << "Model: "; cin >> m;
            fManager.setMaintenance(m);
        } else if (choice == 3) {
            string m; cout << "Model to process: "; cin >> m;
            fManager.processQueue(m);
        } else if (choice == 4) {
            fManager.exportRevenueCSV();
        } else if (choice == 5) {
            uManager.showDefaulters();
        } else if (choice == 6) break;
    }
}

void showCustomerMenu(User* user, UserManager& manager, FleetManager& fleet) {
    int choice;
    while (true) {
        cout << "\n--- CUSTOMER PANEL (" << user->username << ") ---\n";
        cout << "1. View History\n2. Reserve Car\n3. Pay Fines\n4. Logout\nChoice: ";
        cin >> choice;

        if (choice == 1) cout << "History: " << user->history << endl;
        else if (choice == 2) {
            string carName;
            int d1, m1, y1, d2, m2, y2;
            cout << "Model: "; cin >> carName;
            Car* c = fleet.findCar(carName);
            if (!c) { cout << "Not found!\n"; continue; }

            cout << "Start Date (D M Y): "; cin >> d1 >> m1 >> y1;
            cout << "End Date (D M Y): "; cin >> d2 >> m2 >> y2;
            Date start(d1, m1, y1), end(d2, m2, y2);

            if (fleet.addReservation(user->username, carName, start, end)) {
                user->history += "," + carName;
                manager.saveToFile();
                cout << "Reserved successfully!\n";
            } else {
                char join;
                cout << "Dates busy. Join Waitlist? (y/n): "; cin >> join;
                if (join == 'y' || join == 'Y') {
                    c->waitList.push(user->username, 1);
                    cout << "Added to queue.\n";
                }
            }
        } 
        else if (choice == 3) {
            user->balance_due = 0;
            manager.saveToFile();
            cout << "Fines paid.\n";
        } 
        else if (choice == 4) break;
    }
}

int main() {
    UserManager system(USER_FILE);
    FleetManager fleet(CAR_FILE);
    int choice;
    string u, p;

    while (true) {
        cout << "\n--- CAR RENTAL ---\n1. Sign Up\n2. Customer Login\n3. Admin Login\n4. Exit\nChoice: ";
        cin >> choice;
        if (choice == 1) {
            cout << "User: "; cin >> u;
            cout << "Pass: "; cin >> p;
            system.signUp(u, p, "Customer");
        } else if (choice == 2) {
            cout << "User: "; cin >> u;
            cout << "Pass: "; cin >> p;
            User* loggedIn = system.login(u, p);
            if (loggedIn) showCustomerMenu(loggedIn, system, fleet);
        } else if (choice == 3) {
            cout << "Admin: "; cin >> u;
            cout << "Pass: "; cin >> p;
            if (u == "admin" && p == "admin123") showManagerMenu(system, fleet);
        } else if (choice == 4) break;
    }
    return 0;
}