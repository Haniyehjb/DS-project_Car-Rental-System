#ifndef HASHTABLE_H
#define HASHTABLE_H

#include <string>
#include <vector>
#include "User.h" // فرض بر این است که کلاس User را دارید

using namespace std;

struct HashNode {
    string key;
    User* userPtr;
    HashNode* next;

    HashNode(string k, User* u) : key(k), userPtr(u), next(nullptr) {}
};

class HashTable {
private:
    static const int TABLE_SIZE = 100;
    HashNode* table[TABLE_SIZE];

    // تابع هش ساده
    int hashFunction(string key) {
        int hash = 0;
        for (char ch : key) {
            hash = (hash * 31 + ch) % TABLE_SIZE;
        }
        return hash;
    }

public:
    HashTable() {
        for (int i = 0; i < TABLE_SIZE; i++) table[i] = nullptr;
    }

    void insert(string key, User* u) {
        int index = hashFunction(key);
        HashNode* newNode = new HashNode(key, u);
        newNode->next = table[index];
        table[index] = newNode;
    }

    User* search(string key) {
        int index = hashFunction(key);
        HashNode* entry = table[index];
        while (entry) {
            if (entry->key == key) return entry->userPtr;
            entry = entry->next;
        }
        return nullptr;
    }
};

#endif