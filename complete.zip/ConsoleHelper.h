#ifndef CONSOLE_HELPER_H
#define CONSOLE_HELPER_H

#include <iostream>
#include <string>

#ifdef _WIN32
    #ifndef NOMINMAX
        #define NOMINMAX
    #endif
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #include <windows.h>
    #include <conio.h> // برای تابع _getch
#else
    #include <termios.h>
    #include <unistd.h>
#endif

/**
 * دریافت پسورد و نمایش ستاره به جای کاراکترها
 */
inline std::string getHiddenPassword() {
    std::string password = "";
    char ch;

#ifdef _WIN32
    // در ویندوز از _getch استفاده می‌کنیم که کاراکتر را می‌گیرد ولی چاپ نمی‌کند
    while (true) {
        ch = _getch(); // خواندن کاراکتر بدون نمایش

        if (ch == '\r' || ch == '\n') { // اگر اینتر زد
            break;
        } 
        else if (ch == '\b') { // اگر بک‌اسپیس زد
            if (!password.empty()) {
                password.pop_back();
                std::cout << "\b \b"; // پاک کردن یک ستاره از صفحه
            }
        } 
        else if (ch >= 32 && ch <= 126) { // فقط کاراکترهای قابل چاپ
            password += ch;
            std::cout << '*'; // چاپ ستاره به جای کاراکتر
        }
    }
#else
    // بخش لینوکس (اگر نیاز بود)
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    while ((ch = getchar()) != '\n') {
        if (ch == 127 || ch == 8) {
            if (!password.empty()) {
                password.pop_back();
                std::cout << "\b \b";
            }
        } else {
            password += ch;
            std::cout << '*';
        }
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif

    std::cout << std::endl; // رفتن به خط بعد پس از اتمام رمز
    return password;
}

#endif