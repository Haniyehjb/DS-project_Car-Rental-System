#include "FleetManager.h"
#include "UserManager.h"
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#define RESET          "\033[0m"
#define LIME_GREEN     "\033[92m"
#define MYSTERY_BLUE   "\033[94m"
#define ORANGE         "\033[38;5;208m"
#define WHITE          "\033[37m"
#define RED            "\033[31m"

FleetManager::FleetManager(string path) : filePath(path) {
    head = tail = nullptr;
    resHead = nullptr;
    totalRevenue = 0.0;
    loadCars();
    loadReservations();
}

void FleetManager::addCar(string model, double price) {
    Car* newCar = new Car(model, price);
    if (!head) {
        head = tail = newCar;
    } else {
        tail->next = newCar;
        newCar->prev = tail;
        tail = newCar;
    }
    carIndex.insert(model, newCar); 
    saveCars();
}

Car* FleetManager::findCar(string model) {
    return carIndex.search(model); 
}

bool FleetManager::isCarAvailable(string model, Date start, Date end) {
    Car* c = findCar(model);
    if (!c) return false;
    
    if (c->status == MAINTENANCE) {
        cout << RED << "Conflict: This car is currently in MAINTENANCE." << RESET << endl;
        return false;
    }

    Reservation* temp = resHead;
    while (temp) {
        if (temp->carModel == model && temp->isActive) {
            if (start.toDays() < temp->endDate.toDays() && 
                end.toDays() > temp->startDate.toDays()) {
                cout << RED << "Conflict: Car is already RESERVED for these dates." << RESET << endl;
                return false;
            }
        }
        temp = temp->next;
    }
    return true;
}

bool FleetManager::addReservation(string user, string carModel, Date start, Date end) {
    if (!isCarAvailable(carModel, start, end)) return false;

    Car* c = findCar(carModel);
    if (c) {
        Reservation* newRes = new Reservation(user, carModel, start, end);
        newRes->next = resHead;
        resHead = newRes;
        c->status = RENTED;
        c->rentedBy = user;
        saveCars();
        saveReservations(); 
        return true;
    }
    return false;
}

void FleetManager::processQueue(string model, Date startDate, int requestedDays) {
    Car* c = findCar(model);
    if (c && !c->waitList.isEmpty()) {
        WaitRequest nextReq = c->waitList.pop(); 
        string nextUser = nextReq.username;     
        
        Date actualStart = startDate;
        actualStart.day += 3;
        
        Date actualEnd = actualStart;
        actualEnd.day += requestedDays;

        Reservation* newRes = new Reservation(nextUser, model, actualStart, actualEnd);
        newRes->next = resHead;
        resHead = newRes;

        c->status = RENTED;
        c->rentedBy = nextUser;
        saveCars();
        saveReservations();
        cout << "\033[38;5;208mWaitlist: " << nextUser << " assigned " << model << " starting ";
        actualStart.print();
        cout << "\033[0m" << endl;
    }
}

void FleetManager::checkIn(string model, Date actualDate, UserManager& uManager) {
    Car* c = findCar(model);
    if (!c || c->status != RENTED) return;

    Reservation* res = resHead;
    while (res) {
        if (res->carModel == model && res->isActive) {
            int duration = actualDate.toDays() - res->startDate.toDays();
            int plannedDuration = res->endDate.toDays() - res->startDate.toDays();
            if (duration <= 0) duration = 1; 

            double rentalCost = duration * c->pricePerDay;
            double lateFine = 0;
            if (actualDate.toDays() > res->endDate.toDays()) {
                int extra = actualDate.toDays() - res->endDate.toDays();
                lateFine = extra * c->pricePerDay * 1.5;
            }

            uManager.applyFine(res->username, rentalCost + lateFine);
            totalRevenue += (rentalCost + lateFine);
            res->isActive = false;      
            c->status = AVAILABLE;      
            c->rentedBy = "None";       

            saveCars();
            saveReservations();
            processQueue(model, actualDate, plannedDuration);
            return; 
        }
        res = res->next;
    }
}

bool FleetManager::extendRental(string username, string model, int extraDays) {
    Reservation* res = resHead;
    while (res) {
        if (res->carModel == model && res->username == username && res->isActive) {
            Date newEnd = res->endDate;
            newEnd.day += extraDays;
            
            Reservation* temp = resHead;
            while (temp) {
                if (temp != res && temp->carModel == model && temp->isActive) {
                    if (res->endDate.toDays() < temp->endDate.toDays() && newEnd.toDays() > temp->startDate.toDays()) {
                        return false;
                    }
                }
                temp = temp->next;
            }
            res->endDate = newEnd;
            saveReservations();
            return true;
        }
        res = res->next;
    }
    return false;
}

void FleetManager::displayAllCars() {
    Car* temp = head;
    while (temp) {
        cout << "Model: " << temp->model << " | Price: $" << temp->pricePerDay;
        if (temp->status == MAINTENANCE) cout << " | Status: \033[31m[Maintenance]\033[0m";
        else if (temp->status == RENTED) cout << " | Status: [Rented]";
        else cout << " | Status: \033[92m[Available]\033[0m";
        cout << endl;
        temp = temp->next;
    }
    cout << "\033[38;5;208m[Note: Cars marked as MAINTENANCE are currently unavailable]\033[0m" << endl;
}

void FleetManager::displayRentedCars() {
    bool found = false;
    Car* temp = head;
    while (temp) {
        if (temp->status == RENTED) {
            found = true;
            cout << "Model: " << temp->model << " | Renter: " << temp->rentedBy;
            Reservation* res = resHead;
            while (res) {
                if (res->carModel == temp->model && res->isActive) {
                    cout << " | Expected Return: ";
                    res->endDate.print();
                    break;
                }
                res = res->next;
            }
            cout << endl;
        }
        temp = temp->next;
    }
    if (!found) cout << "No active rentals." << endl;
}

void FleetManager::saveReservations() {
    ofstream out("reservations.txt");
    Reservation* temp = resHead;
    while (temp) {
        out << temp->username << " " << temp->carModel << " " 
            << temp->startDate.day << " " << temp->startDate.month << " " << temp->startDate.year << " "
            << temp->endDate.day << " " << temp->endDate.month << " " << temp->endDate.year << " "
            << (temp->isActive ? 1 : 0) << endl;
        temp = temp->next;
    }
    out.close();
}

void FleetManager::loadReservations() {
    ifstream in("reservations.txt");
    if (!in) return;
    string un, model;
    int d1, m1, y1, d2, m2, y2, active;
    while (in >> un >> model >> d1 >> m1 >> y1 >> d2 >> m2 >> y2 >> active) {
        Reservation* newRes = new Reservation(un, model, Date(d1, m1, y1), Date(d2, m2, y2));
        newRes->isActive = (active == 1);
        newRes->next = resHead;
        resHead = newRes;
    }
}

void FleetManager::saveCars() {
    ofstream outFile(filePath);
    Car* temp = head;
    while (temp) {
        outFile << temp->model << " " << temp->pricePerDay << " " << static_cast<int>(temp->status) << " " << (temp->rentedBy.empty() ? "None" : temp->rentedBy) << endl;
        temp = temp->next;
    }
}

void FleetManager::loadCars() {
    ifstream inFile(filePath);
    if (!inFile) return;
    string m, rb; double p; int s;
    while (inFile >> m >> p >> s >> rb) {
        Car* newCar = new Car(m, p);
        newCar->status = static_cast<CarStatus>(s);
        newCar->rentedBy = (rb == "None" ? "" : rb);
        if (!head) head = tail = newCar;
        else { tail->next = newCar; newCar->prev = tail; tail = newCar; }
        carIndex.insert(m, newCar);
    }
}

void FleetManager::confirmPickup(string model) {
    Car* c = findCar(model);
    if (c) { 
        c->status = RENTED; 
        saveCars(); 
        cout << LIME_GREEN << "Success: Car " << model << " status updated to RENTED." << RESET << endl;
    } else {
        cout << RED << "Error: Model not found." << RESET << endl;
    }
}

void FleetManager::saveToFile() { saveCars(); }

void FleetManager::exportRevenueCSV() {
    ofstream csvFile("revenue_report.csv");
    csvFile << "User,Car,TotalAccountRevenue" << endl;
    csvFile << "Total," << "All," << totalRevenue << endl;
    cout << "Exported to revenue_report.csv" << endl;
}

FleetManager::~FleetManager() {
    Car* c = head; while (c) { Car* n = c->next; delete c; c = n; }
    Reservation* r = resHead; while (r) { Reservation* n = r->next; delete r; r = n; }
}