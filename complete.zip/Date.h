#ifndef DATE_H
#define DATE_H

#include <iostream>
using namespace std;

struct Date {
    int totalMinutes;

    Date(int minutes = 0) : totalMinutes(minutes) {}

    // Overloading operators for easy comparison
    bool operator<(const Date& other) const { return totalMinutes < other.totalMinutes; }
    bool operator>(const Date& other) const { return totalMinutes > other.totalMinutes; }
    bool operator<=(const Date& other) const { return totalMinutes <= other.totalMinutes; }
    bool operator>=(const Date& other) const { return totalMinutes >= other.totalMinutes; }
    
    void print() const {
        cout << "Minute: " << totalMinutes;
    }
};

#endif