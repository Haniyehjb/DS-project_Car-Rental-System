#include "FleetManager.h"
#include "UserManager.h"
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

FleetManager::FleetManager(string path) : filePath(path) {
    head = tail = nullptr;
    resHead = nullptr;
    totalRevenue = 0.0;
    loadCars();
}

void FleetManager::addCar(string model, double price) {
    Car* newCar = new Car(model, price);
    if (!head) {
        head = tail = newCar;
    } else {
        tail->next = newCar;
        newCar->prev = tail;
        tail = newCar;
    }
    carIndex.insert(model, newCar); 
    saveCars();
}

Car* FleetManager::findCar(string model) {
    return carIndex.search(model);
}

bool FleetManager::isCarAvailable(string model, Date start, Date end) {
    Car* c = findCar(model);
    if (!c || c->status == MAINTENANCE) return false;

    Reservation* temp = resHead;
    while (temp) {
        if (temp->carModel == model && temp->isActive) {
            if (!(end < temp->startDate || start > temp->endDate)) {
                return false; 
            }
        }
        temp = temp->next;
    }
    return true;
}

bool FleetManager::addReservation(string user, string carModel, Date start, Date end) {
    if (!isCarAvailable(carModel, start, end)) return false;

    Car* c = findCar(carModel);
    if (c) {
        Reservation* newRes = new Reservation(user, carModel, start, end);
        newRes->next = resHead;
        resHead = newRes;

        c->status = RENTED;
        c->rentedBy = user;
        saveCars(); 
        return true;
    }
    return false;
}

void FleetManager::displayAllCars() {
    Car* temp = head;
    cout << "\n------------------------------------------------------------------\n";
    printf("%-15s %-12s %-15s %-15s\n", "Model", "Price/Day", "Status", "Rented By");
    cout << "------------------------------------------------------------------\n";
    
    while (temp != nullptr) {
        string statusStr = (temp->status == AVAILABLE) ? "Available" : 
                          (temp->status == MAINTENANCE ? "Maintenance" : "Rented");
        
        printf("%-15s %-12.0f %-15s %-15s\n", 
               temp->model.c_str(), temp->pricePerDay, statusStr.c_str(), temp->rentedBy.c_str());
        temp = temp->next;
    }
    cout << "------------------------------------------------------------------\n";
}

void FleetManager::processQueue(string model) {
    Car* c = findCar(model);
    if (c && !c->waitList.isEmpty()) {
        string nextUser = c->waitList.pop();
        c->status = RENTED;
        c->rentedBy = nextUser;
        cout << "Queue Alert: Car " << model << " assigned to " << nextUser << endl;
        saveCars();
    }
}

void FleetManager::processReturn(string model, int actualMinutes, char health, UserManager& uManager) {
    Car* c = findCar(model);
    if (!c || c->status != RENTED) {
        cout << "Error: Car not found or not rented.\n";
        return;
    }

    if (actualMinutes > 5) {
        double fine = (actualMinutes - 5) * (c->pricePerDay * 0.5);
        uManager.applyFine(c->rentedBy, fine);
        totalRevenue += fine;
        cout << "Late Return Fine: " << fine << endl;
    }

    if (health == 'n' || health == 'N') {
        c->status = MAINTENANCE;
        cout << "Car moved to MAINTENANCE.\n";
    } else {
        c->status = AVAILABLE;
        c->rentedBy = "None";
        cout << "Car returned successfully.\n";
        processQueue(model);
    }
    saveCars();
}

void FleetManager::displayRentedCars() {
    Car* temp = head;
    bool found = false;
    cout << "\n--- ADMIN: ACTIVE RENTALS ---\n";
    while (temp) {
        if (temp->status == RENTED) {
            cout << "Model: " << temp->model << " | User: " << temp->rentedBy << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No active rentals found.\n";
}

void FleetManager::saveCars() {
    ofstream outFile(filePath);
    Car* temp = head;
    while (temp) {
        outFile << temp->model << " " << temp->pricePerDay << " " << (int)temp->status << " " << temp->rentedBy << endl;
        temp = temp->next;
    }
    outFile.close();
}

void FleetManager::loadCars() {
    ifstream inFile(filePath);
    if (!inFile) return;
    string m, rb; double p; int s;
    while (inFile >> m >> p >> s >> rb) {
        Car* newCar = new Car(m, p);
        newCar->status = static_cast<CarStatus>(s);
        newCar->rentedBy = rb;
        if (!head) head = tail = newCar;
        else { tail->next = newCar; newCar->prev = tail; tail = newCar; }
        carIndex.insert(m, newCar);
    }
}

void FleetManager::exportRevenueCSV() {
    ofstream csvFile("revenue_report.csv");
    csvFile << "Total Revenue," << totalRevenue << endl;
    csvFile.close();
    cout << "Report exported to revenue_report.csv\n";
}

void FleetManager::setMaintenance(string model) {
    Car* c = findCar(model);
    if (c) {
        c->status = MAINTENANCE;
        saveCars();
    }
}

bool FleetManager::extendRental(string username, string carModel, int extraDays, UserManager& uManager) {
    Car* c = findCar(carModel);
    if (c && c->rentedBy == username && c->waitList.isEmpty()) {
        double cost = extraDays * c->pricePerDay;
        uManager.applyFine(username, cost);
        totalRevenue += cost;
        saveCars();
        return true;
    }
    return false;
}