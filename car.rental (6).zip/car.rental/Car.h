#ifndef CAR_H
#define CAR_H

#include <string>
#include "PriorityQueue.h"
using namespace std;

enum CarStatus { AVAILABLE, RENTED, MAINTENANCE };

class Car {
public:
    string model;
    double pricePerDay;
    CarStatus status;
    PriorityQueue waitList; // صف انتظار برای این خودرو
    Car* next;
    Car* prev;

    Car(string m, double p) {
        model = m;
        pricePerDay = p;
        status = AVAILABLE;
        next = prev = nullptr;
    }
};

#endif