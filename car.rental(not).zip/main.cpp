#include <iostream>
#include <string>
#include "UserManager.h"
#include "FleetManager.h"

using namespace std;

void showManagerMenu(UserManager& uM, FleetManager& fM) {
    int choice;
    while (true) {
        cout << "\n--- ADMIN PANEL ---\n1. Add New Car\n2. View Active Rentals\n3. Manual Repair/Fine\n4. Block/Unblock User\n5. Export Revenue\n6. Logout\nChoice: ";
        if (!(cin >> choice)) break;
        
        if (choice == 1) {
            string m; double p; 
            cout << "Enter Model: "; cin >> m; 
            cout << "Enter Price per Minute: "; cin >> p;
            fM.addCar(m, p);
        } else if (choice == 2) { 
            fM.displayRentedCars(); 
        } else if (choice == 3) {
            string m, u; double cost;
            cout << "Car Model: "; cin >> m; 
            cout << "Target Username: "; cin >> u; 
            cout << "Repair Cost: "; cin >> cost;
            uM.applyFine(u, cost);
        } else if (choice == 4) {
            string u; cout << "Enter Username: "; cin >> u; 
            uM.toggleBlockStatus(u);
        } else if (choice == 5) {
            fM.exportRevenueCSV();
        } else if (choice == 6) break;
    }
}

void showCustomerMenu(User* user, UserManager& uM, FleetManager& fM) {
    int choice;
    while (true) {
        cout << "\n--- CUSTOMER: " << user->username << " ---\n";
        cout << "1. View Fleet\n2. Reserve a Car\n3. Return Car (Check-in)\n4. Logout\nChoice: ";
        cin >> choice;
        
        if (choice == 1) {
            fM.displayAllCars();
        } else if (choice == 2) {
            string m; int start, end;
            cout << "Car Model: "; cin >> m;
            cout << "Start Minute: "; cin >> start;
            cout << "End Minute: "; cin >> end;
            if (fM.addReservation(user->username, m, Date(start), Date(end))) {
                cout << "Success! Car reserved from " << start << " to " << end << ".\n";
            } else {
                cout << "Error: Car unavailable or under maintenance.\n";
            }
        } else if (choice == 3) {
            string m; int actualMin; char health;
            cout << "Return Car Model: "; cin >> m; 
            cout << "Current Minute: "; cin >> actualMin; 
            cout << "Is car healthy? (y/n): "; cin >> health;
            fM.processReturn(m, actualMin, health, uM);
        } else if (choice == 4) break;
    }
}

int main() {
    UserManager uM("users.txt");
    FleetManager fM("cars.txt");
    int choice;

    while (true) {
        cout << "\n=== CAR RENTAL SYSTEM ===\n1. Sign Up\n2. User Login\n3. Admin Login\n4. Exit\nChoice: ";
        if (!(cin >> choice)) break;

        if (choice == 1) {
            string u, p;
            cout << "New Username: "; cin >> u;
            cout << "New Password: "; cin >> p;
            if (uM.signUp(u, p, "Customer")) cout << "Account created!\n";
            else cout << "Username already exists.\n";
        } else if (choice == 2) {
            string u, p;
            cout << "Username: "; cin >> u;
            cout << "Password: "; cin >> p;
            User* user = uM.login(u, p);
            if (user && !user->isBlocked) showCustomerMenu(user, uM, fM);
            else if (user) cout << "ACCESS DENIED: Account is blocked.\n";
            else cout << "Invalid credentials.\n";
        } else if (choice == 3) {
            string u, p;
            cout << "Admin Username: "; cin >> u;
            cout << "Admin Password: "; cin >> p;
            if (u == "admin" && p == "admin123") showManagerMenu(uM, fM);
            else cout << "Invalid Admin Login.\n";
        } else if (choice == 4) break;
    }
    return 0;
}