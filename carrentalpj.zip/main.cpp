#include <iostream>
#include <string>
#include <limits>
#include <cstdlib>
#include <conio.h> 

#include "UserManager.h"
#include "FleetManager.h"
#include "Date.h"

using namespace std; 

#define RESET          "\033[0m"
#define LIME_GREEN     "\033[92m"
#define MYSTERY_BLUE   "\033[94m"
#define ORANGE         "\033[38;5;208m"
#define WHITE          "\033[37m"
#define RED            "\033[31m"

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void pause() {
    cout << "\n" << WHITE << "Press Enter to continue..." << RESET;
    _getch(); 
}

void printLogo() {
    cout << LIME_GREEN << "================================================" << endl;
    cout << MYSTERY_BLUE << "  __  __ __  __  ___  _____  ____  ___  __  __ " << endl;
    cout << MYSTERY_BLUE << " |  \\/  |\\ \\/ / / __||_   _|| ___|| _ \\ \\ \\/ / " << endl;
    cout << MYSTERY_BLUE << " | |\\/| | \\  /  \\__ \\  | |  | __| |   <  \\  /  " << endl;
    cout << MYSTERY_BLUE << " |_|  |_|  |_|  |___/  |_|  |____||_|_\\  |_|   " << endl;
    cout << endl;
    cout << "        " << ORANGE << ">> Zoinks! Let's rent a ride! <<" << endl;
    cout << LIME_GREEN << "================================================" << RESET << endl << endl;
}

string getHiddenPassword() {
    string password = "";
    char ch;
    while ((ch = _getch()) != 13) {
        if (ch == 8) {
            if (password.length() > 0) {
                cout << "\b \b";
                password.pop_back();
            }
        } else {
            password += ch;
            cout << '*';
        }
    }
    cout << endl;
    return password;
}

int getMenuChoice(string options[], int numOptions, string title) {
    int selected = 0;
    while (true) {
        clearScreen();
        printLogo();
        cout << WHITE << "   --- " << title << " ---" << RESET << endl << endl;

        for (int i = 0; i < numOptions; ++i) {
            if (i == selected)
                cout << ORANGE << " > " << options[i] << RESET << endl;
            else
                cout << WHITE << "   " << options[i] << RESET << endl;
        }

        int key = _getch();
        if (key == 0 || key == 224) { 
            key = _getch();
            if (key == 72) selected = (selected - 1 + numOptions) % numOptions;
            else if (key == 80) selected = (selected + 1) % numOptions;
        } else if (key == 13) { 
            return selected + 1;
        }
    }
}

void showManagerMenu(UserManager& uM, FleetManager& fM) {
    string options[] = {
        "1. Add New Car to Fleet", 
        "2. View All Active Rentals", 
        "3. Apply Manual Fine / Repair Cost", 
        "4. Block / Unblock User", 
        "5. Export Revenue Report (CSV)", 
        "6. Confirm Car Pickup (Set to RENTED)", 
        "7. Process Return (Health Check & Check-in)",
        "8. Logout"
    };
    int num = 8;

    while (true) {
        int choice = getMenuChoice(options, num, "ADMIN PANEL (STAFF)");

        if (choice == 1) {
            string m; double p;
            cout << "Enter Car Model: "; cin >> m;
            cout << "Enter Rental Price: "; cin >> p;
            fM.addCar(m, p);
            pause();
        } else if (choice == 2) {
            fM.displayRentedCars();
            pause();
        } else if (choice == 3) {
            string u; double cost;
            cout << "Username: "; cin >> u;
            cout << "Amount: "; cin >> cost;
            uM.applyFine(u, cost);
            pause();
        } else if (choice == 4) {
            string u; cout << "Username to Toggle: "; cin >> u;
            uM.toggleBlockStatus(u);
            pause();
        } else if (choice == 5) {
            fM.exportRevenueCSV();
            pause();
        } else if (choice == 6) {
            string m; cout << "Model: "; cin >> m;
            fM.confirmPickup(m);
            pause();
        } else if (choice == 7) { 
            string m; 
            cout << "Model: "; cin >> m;
            Car* car = fM.findCar(m);
            if (car) {
                char health;
                cout << "Healthy? (y/n): "; cin >> health;
                if (health == 'n' || health == 'N') {
                    car->status = MAINTENANCE; 
                    string u; double fine;
                    cout << "Username for fine: "; cin >> u;
                    cout << "Fine: $"; cin >> fine;
                    uM.applyFine(u, fine);
                    cout << ORANGE << "Fine applied." << RESET << endl;
                } else {
                    int d, mon, y;
                    cout << "Return Date (D M Y): "; cin >> d >> mon >> y;
                    fM.checkIn(m, Date(d, mon, y), uM);
                    cout << LIME_GREEN << "Processed." << RESET << endl;
                }
                fM.saveToFile(); uM.saveToFile();
            } else {
                cout << RED << "Error: Model '" << m << "' does not exist." << RESET << endl;
            }
            pause();
        } else if (choice == 8) break;
    }
}

void showCustomerMenu(User* user, UserManager& uM, FleetManager& fM) {
    string options[] = {
        "1. View Fleet & Return Times",
        "2. Reserve a Car",
        "3. Extend Reservation",
        "4. Return Car (Check-in)",
        "5. Pay Outstanding Balance",
        "6. Logout"
    };
    int num = 6;

    while (true) {
        string title = "WELCOME, " + user->username + " | Debt: $" + to_string((int)user->balance_due);
        int choice = getMenuChoice(options, num, title);

        if (choice == 1) {
            clearScreen();
            fM.displayAllCars();
            pause();
        } else if (choice == 2) {
            if (user->balance_due > 1000) {
                cout << RED << "\n[!] ACCESS DENIED: Debt too high ($" << user->balance_due << ")." << RESET << endl;
            } else {
                string model; cout << "\nEnter Model: "; cin >> model;
                Car* car = fM.findCar(model);
                if (car) {
                    int sd, sm, sy, ed, em, ey;
                    cout << "Start (D M Y): "; cin >> sd >> sm >> sy;
                    cout << "End (D M Y): "; cin >> ed >> em >> ey;
                    if (fM.addReservation(user->username, model, Date(sd, sm, sy), Date(ed, em, ey))) {
                        cout << LIME_GREEN << "Success!" << RESET << endl;
                    } else {
                        cout << "Waitlist? (y/n): ";
                        char j; cin >> j;
                        if (j == 'y' || j == 'Y') car->waitList.push(user->username, 1);
                    }
                } else {
                    cout << RED << "Error: Car '" << model << "' not found." << RESET << endl;
                }
            }
            pause();
        } else if (choice == 3) {
            bool foundAny = false;
            Reservation* temp = fM.resHead;
            while(temp) {
                if(temp->username == user->username && temp->isActive) {
                    cout << "Active Rental: " << temp->carModel << " | Until: ";
                    temp->endDate.print(); cout << endl;
                    foundAny = true;
                }
                temp = temp->next;
            }
            if(!foundAny) cout << "No active rentals found to extend." << endl;
            else {
                string m; int extra;
                cout << "Enter Model to extend: "; cin >> m;
                if (fM.findCar(m)) {
                    cout << "Extra days: "; cin >> extra;
                    if(fM.extendRental(user->username, m, extra)) cout << LIME_GREEN << "Extended!" << RESET << endl;
                    else cout << RED << "Cannot extend: Conflict detected." << RESET << endl;
                } else {
                    cout << RED << "Error: Model '" << m << "' does not exist." << RESET << endl;
                }
            }
            pause();
        } else if (choice == 4) {
            string m; int d, mon, y;
            cout << "Model: "; cin >> m;
            if (fM.findCar(m)) {
                cout << "Date (D M Y): "; cin >> d >> mon >> y;
                fM.checkIn(m, Date(d, mon, y), uM); 
                User* updated = uM.login(user->username, ""); 
                if(updated) user->balance_due = updated->balance_due;
            } else {
                cout << RED << "Error: Model not found." << RESET << endl;
            }
            pause();
        } else if (choice == 5) {
            clearScreen();
            cout << WHITE << "--- PAYMENT DETAILS ---" << RESET << endl;
            cout << "Account Holder: " << user->username << endl;
            cout << "Current Debt: " << ORANGE << "$" << user->balance_due << RESET << endl << endl;
            if (user->balance_due > 0) {
                double amt; cout << "Enter amount to pay: "; cin >> amt;
                uM.payFine(user->username, amt);
                User* updated = uM.login(user->username, ""); 
                if(updated) user->balance_due = updated->balance_due;
                cout << LIME_GREEN << "Payment processed." << RESET << endl;
            } else {
                cout << LIME_GREEN << "Your account balance is clear." << RESET << endl;
            }
            pause();
        } else if (choice == 6) break;
    }
}

int main() {
    UserManager uM("users.txt");
    FleetManager fM("cars.txt");
    string mainMenu[] = {"1. Sign Up", "2. User Login", "3. Admin Login", "4. Exit"};
    while (true) {
        int choice = getMenuChoice(mainMenu, 4, "CAR RENTAL SYSTEM");
        if (choice == 1) {
            string u, p; cout << "Username: "; cin >> u;
            cout << "Password: "; p = getHiddenPassword();
            if (uM.signUp(u, p, "Customer")) {
                cout << LIME_GREEN << "Success! Account created." << RESET << endl;
            } else {
                cout << RED << "Error: Username already exists." << RESET << endl;
            }
            pause();
        } else if (choice == 2) {
            string u, p; cout << "Username: "; cin >> u;
            cout << "Password: "; p = getHiddenPassword();
            User* user = uM.login(u, p);
            if (user && !user->isBlocked) showCustomerMenu(user, uM, fM);
            else if (user && user->isBlocked) { 
                cout << RED << "Access Denied: Your account is BLOCKED." << RESET << endl; 
                pause();
            } else {
                cout << RED << "Access Denied: Invalid credentials." << RESET << endl;
                pause();
            }
        } else if (choice == 3) {
            string u, p; cout << "ID: "; cin >> u;
            cout << "Password: "; p = getHiddenPassword();
            if (u == "admin" && p == "admin123") showManagerMenu(uM, fM);
            else { 
                cout << RED << "Access Denied: Invalid Admin credentials." << RESET << endl; 
                pause(); 
            }
        } else if (choice == 4) break;
    }
    return 0;
}