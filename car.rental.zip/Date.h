#ifndef DATE_H
#define DATE_H

#include <iostream>
using namespace std;

struct Date {
    int day, month, year;

    Date(int d = 0, int m = 0, int y = 0) : day(d), month(m), year(y) {}

    // تبدیل تاریخ به عدد کل روزها برای مقایسه راحت
    int toDays() const {
        return year * 365 + month * 30 + day; 
    }

    bool operator<(const Date& other) const { return toDays() < other.toDays(); }
    bool operator>(const Date& other) const { return toDays() > other.toDays(); }
    bool operator<=(const Date& other) const { return toDays() <= other.toDays(); }
    bool operator>=(const Date& other) const { return toDays() >= other.toDays(); }
};

#endif