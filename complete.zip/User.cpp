#include "User.h"

// Standardized hashing to match UserManager
string simpleHash(string password) {
    string hashed = password;
    for (int i = 0; i < hashed.length(); i++) hashed[i] = hashed[i] + 3; 
    return hashed;
}

User::User(string un, string pw, string r) {
    username = un;
    passwordHash = pw; // UserManager handles the hashing before calling this
    role = r;
    balance_due = 0.0;
    history = "";
    isBlocked = false; 
    next = nullptr;
}
