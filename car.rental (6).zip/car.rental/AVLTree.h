#ifndef AVLTREE_H
#define AVLTREE_H

#include <string>
#include <algorithm>
#include "Car.h"

using namespace std;

struct AVLNode {
    string key;
    Car* carPtr;
    AVLNode *left, *right;
    int height;

    AVLNode(string k, Car* ptr) 
        : key(k), carPtr(ptr), left(nullptr), right(nullptr), height(1) {}
};

class AVLTree {
private:
    AVLNode* root;
    int height(AVLNode* n);
    int getBalance(AVLNode* n);
    AVLNode* rightRotate(AVLNode* y);
    AVLNode* leftRotate(AVLNode* x);
    AVLNode* insert(AVLNode* node, string key, Car* ptr);
    Car* search(AVLNode* root, string key);

public:
    AVLTree() : root(nullptr) {}
    void insert(string key, Car* ptr) { root = insert(root, key, ptr); }
    Car* search(string key) { return search(root, key); }
};

#endif