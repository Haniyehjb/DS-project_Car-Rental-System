#ifndef USER_MANAGER_H
#define USER_MANAGER_H

#include "User.h"
#include <string>

using namespace std;

class UserManager {
private:
    static const int HASH_TABLE_SIZE = 100;
    User* hashTable[HASH_TABLE_SIZE];
    User* head; 
    string filePath;

    int getHash(string key);

public:
    UserManager(string path);
    void showDefaulters();
    void saveToFile();
    void loadFromFile();
    bool signUp(string username, string password, string role);
    User* findUser(string username);
    User* login(string username, string password);
    void applyFine(string username, double amount);
};

#endif