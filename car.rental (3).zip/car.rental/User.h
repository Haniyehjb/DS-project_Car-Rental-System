#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

unsigned long long hashPassword(string str);

class User {
public:
    string username;
    unsigned long long passwordHash;
    string role;
    double balance_due; 
    string history;
    User* next;

    User(string un, string pw, string r);
};

#endif