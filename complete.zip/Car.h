#ifndef CAR_H
#define CAR_H

#include "Date.h"
#include "PriorityQueue.h"
#include <string>

using namespace std;

enum CarStatus { AVAILABLE, RENTED, MAINTENANCE };

class Car {
public:
    string model;
    double pricePerDay;
    CarStatus status;
    string rentedBy;           
    PriorityQueue waitList;
    Car* next;
    Car* prev;

    Car(string m, double p) : model(m), pricePerDay(p), status(AVAILABLE), rentedBy("None"), next(nullptr), prev(nullptr) {}
};

#endif