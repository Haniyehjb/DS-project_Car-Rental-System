#include <iostream>
#include <string>
#include "UserManager.h"
#include "FleetManager.h"
#include "Date.h"

using namespace std;

const string USER_FILE = "users.txt";
const string CAR_FILE = "cars.txt";

// --- مدیریت منوی مدیر ---
void showManagerMenu(UserManager& uManager, FleetManager& fManager) {
    int choice;
    while (true) {
        cout << "\n--- MANAGER PANEL ---\n1. Add Car\n2. Maintenance\n3. Process Waitlist\n4. Revenue CSV\n5. Defaulters (Debt > 1000)\n6. Logout\nChoice: ";
        cin >> choice;
        if (choice == 1) {
            string m; double p;
            cout << "Model: "; cin >> m;
            cout << "Price/Day: "; cin >> p;
            fManager.addCar(m, p);
        } else if (choice == 2) {
            string m; cout << "Model: "; cin >> m;
            fManager.setMaintenance(m);
        } else if (choice == 3) {
            string m; cout << "Model to process: "; cin >> m;
            fManager.processQueue(m);
        } else if (choice == 4) {
            fManager.exportRevenueCSV();
        } else if (choice == 5) {
            uManager.showDefaulters(); 
        } else if (choice == 6) break;
    }
}

// --- مدیریت منوی مشتری ---
void showCustomerMenu(User* user, UserManager& manager, FleetManager& fleet) {
    int choice;
    while (true) {
        cout << "\n--- CUSTOMER MENU ---\n";
        cout << "1. View All Cars\n";
        cout << "2. Reserve a Car (Quotation & Confirm)\n";
        cout << "3. My History & Balance\n";
        cout << "4. Pay Fines\n";
        cout << "5. Logout\n";
        cout << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            fleet.displayAllCars();
        } 
        else if (choice == 2) {
            // ۱. بررسی شرط بدحسابی (بدهی بالای 1000)
            if (user->balance_due > 1000) {
                cout << "\n[!] ACCESS DENIED: Your debt is " << user->balance_due << " Toman.\n";
                cout << "Please pay your fines (Option 4) before making a new reservation.\n";
                continue;
            }

            // ۲. چاپ خودکار لیست خودروها
            fleet.displayAllCars();

            string model;
            cout << "\nEnter car model name to reserve: "; 
            cin >> model;

            Car* car = fleet.findCar(model);
            if (!car) {
                cout << "Error: Car model not found!\n";
                continue;
            }

            if (car->status != AVAILABLE) {
                cout << "This car is " << (car->status == MAINTENANCE ? "under maintenance." : "already rented.") << endl;
                cout << "Join waitlist? (y/n): ";
                char join; cin >> join;
                if (join == 'y' || join == 'Y') {
                    car->waitList.push(user->username, 1);
                    cout << "Added to waitlist.\n";
                }
            } 
            else {
                // ۳. دریافت تاریخ و محاسبه قیمت
                int d, m, y;
                cout << "Start Date (Day Month Year): "; cin >> d >> m >> y;
                Date start(d, m, y);
                cout << "End Date (Day Month Year): "; cin >> d >> m >> y;
                Date end(d, m, y);

                int days = end.toDays() - start.toDays() + 1;
                if (days <= 0) days = 1;
                double totalCost = days * car->pricePerDay;

                // ۴. نمایش پیش‌نمایش قیمت (Quotation)
                cout << "\n======================================" << endl;
                cout << "       RESERVATION QUOTATION        " << endl;
                cout << "======================================" << endl;
                cout << "Car Model:    " << model << endl;
                cout << "Daily Rate:   " << car->pricePerDay << " Toman" << endl;
                cout << "Total Days:   " << days << " days" << endl;
                cout << "TOTAL PRICE:  " << totalCost << " Toman" << endl;
                cout << "======================================" << endl;
                
                char confirm;
                cout << "Confirm reservation and add to your debt? (y/n): ";
                cin >> confirm;

                if (confirm == 'y' || confirm == 'Y') {
                    if (fleet.addReservation(user->username, model, start, end)) {
                        // ۵. اضافه کردن به بدهی و تاریخچه
                        user->balance_due += totalCost;

                        if (user->history == "No_History" || user->history == "") {
                            user->history = model;
                        } else {
                            user->history += "_" + model;
                        }

                        // ۶. ذخیره در فایل‌ها
                        manager.saveToFile();
                        fleet.saveCars();
                        
                        cout << "SUCCESS! Reservation confirmed. Your new balance: " << user->balance_due << endl;
                    } else {
                        cout << "Error: This car is already booked for these dates.\n";
                    }
                } else {
                    cout << "Reservation cancelled.\n";
                }
            }
        }
        else if (choice == 3) {
            cout << "\n--- ACCOUNT SUMMARY ---\n";
            cout << "Username: " << user->username << endl;
            cout << "Current Debt: " << user->balance_due << " Toman" << endl;
            cout << "Rental History: " << (user->history == "" ? "None" : user->history) << endl;
        }
        else if (choice == 4) {
            if (user->balance_due <= 0) {
                cout << "No outstanding debt to pay.\n";
            } else {
                cout << "Your Total Debt: " << user->balance_due << " Toman\n";
                double pay;
                cout << "Enter amount to pay: "; cin >> pay;
                
                if (pay > user->balance_due) pay = user->balance_due;
                if (pay < 0) pay = 0;

                user->balance_due -= pay;
                manager.saveToFile();
                cout << "Payment successful. Remaining balance: " << user->balance_due << endl;
            }
        }
        else if (choice == 5) break;
    }
}

// --- تابع اصلی ---
int main() {
    UserManager system(USER_FILE);
    FleetManager fleet(CAR_FILE);
    int choice;
    string u, p;

    while (true) {
        cout << "\n--- LUXURY CAR RENTAL SYSTEM ---\n1. Sign Up\n2. Customer Login\n3. Admin Login\n4. Exit\nChoice: ";
        cin >> choice;
        
        if (choice == 1) {
            cout << "Username: "; cin >> u;
            cout << "Password: "; cin >> p;
            system.signUp(u, p, "Customer");
        } 
        else if (choice == 2) {
            cout << "Username: "; cin >> u;
            cout << "Password: "; cin >> p;
            User* loggedIn = system.login(u, p);
            if (loggedIn) {
                showCustomerMenu(loggedIn, system, fleet);
            } else {
                cout << "Login failed! Please check your username and password.\n";
            }
        } 
        else if (choice == 3) {
            cout << "Admin: "; cin >> u;
            cout << "Pass: "; cin >> p;
            if (u == "admin" && p == "admin123") {
                showManagerMenu(system, fleet);
            } else {
                cout << "Invalid Admin Credentials!\n";
            }
        } 
        else if (choice == 4) {
            break;
        }
    }
    return 0;
}