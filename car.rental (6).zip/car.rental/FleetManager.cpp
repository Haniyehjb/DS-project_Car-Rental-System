#include "FleetManager.h"
#include "UserManager.h"
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

// سازنده کلاس
FleetManager::FleetManager(string path) : filePath(path) {
    head = tail = nullptr;
    resHead = nullptr;
    totalRevenue = 0.0;
    loadCars();
}

// اضافه کردن خودرو جدید
void FleetManager::addCar(string model, double price) {
    Car* newCar = new Car(model, price);
    if (!head) {
        head = tail = newCar;
    } else {
        tail->next = newCar;
        newCar->prev = tail;
        tail = newCar;
    }
    carIndex.insert(model, newCar); 
    saveCars();
}

// جستجوی خودرو بر اساس مدل
Car* FleetManager::findCar(string model) {
    return carIndex.search(model);
}

// بررسی در دسترس بودن خودرو در بازه زمانی
bool FleetManager::isCarAvailable(string model, Date start, Date end) {
    Car* c = findCar(model);
    if (!c || c->status == MAINTENANCE) return false;

    Reservation* temp = resHead;
    while (temp) {
        if (temp->carModel == model && temp->isActive) {
            // چک کردن تداخل بازه‌های زمانی
            if (!(end < temp->startDate || start > temp->endDate)) {
                return false; 
            }
        }
        temp = temp->next;
    }
    return true;
}

// ثبت رزرو و تغییر وضعیت خودرو
bool FleetManager::addReservation(string user, string carModel, Date start, Date end) {
    if (!isCarAvailable(carModel, start, end)) return false;

    Car* c = findCar(carModel);
    if (c) {
        Reservation* newRes = new Reservation(user, carModel, start, end);
        newRes->next = resHead;
        resHead = newRes;

        c->status = RENTED; // تغییر وضعیت به اجاره شده
        saveCars(); 
        return true;
    }
    return false;
}

// پیدا کردن دورترین تاریخ بازگشت برای خودروهای اجاره شده
Date FleetManager::getReturnDate(string model) {
    Reservation* temp = resHead;
    Date latest(0, 0, 0); 

    while (temp) {
        if (temp->carModel == model && temp->isActive) {
            if (latest.year == 0 || temp->endDate.toDays() > latest.toDays()) {
                latest = temp->endDate;
            }
        }
        temp = temp->next;
    }
    return latest;
}

// نمایش لیست خودروها به همراه ستون تاریخ بازگشت
void FleetManager::displayAllCars() {
    Car* temp = head;
    cout << "\n------------------------------------------------------------------\n";
    cout << "                     SHOWROOM FLEET LIST                          \n";
    cout << "------------------------------------------------------------------\n";
    printf("%-15s %-12s %-15s %-15s\n", "Model", "Price/Day", "Status", "Return Date");
    cout << "------------------------------------------------------------------\n";
    
    while (temp != nullptr) {
        string statusStr;
        string returnDateStr = "-";

        if (temp->status == AVAILABLE) {
            statusStr = "Available";
        } else if (temp->status == MAINTENANCE) {
            statusStr = "Maintenance";
        } else {
            statusStr = "Rented";
            Date d = getReturnDate(temp->model);
            if (d.year != 0) {
                returnDateStr = to_string(d.day) + "/" + to_string(d.month) + "/" + to_string(d.year);
            }
        }

        printf("%-15s %-12.0f %-15s %-15s\n", 
               temp->model.c_str(), temp->pricePerDay, statusStr.c_str(), returnDateStr.c_str());
        
        temp = temp->next;
    }
    cout << "------------------------------------------------------------------\n";
}

// مدیریت صف انتظار
void FleetManager::processQueue(string model) {
    Car* c = findCar(model);
    if (c && !c->waitList.isEmpty()) {
        string nextUser = c->waitList.pop();
        cout << "Car " << model << " assigned to: " << nextUser << " from waitlist.\n";
    } else {
        cout << "No waitlist for this car.\n";
    }
}

// تنظیم وضعیت تعمیرات
void FleetManager::setMaintenance(string model) {
    Car* target = findCar(model);
    if (target) {
        target->status = MAINTENANCE; 
        saveCars();
        cout << model << " is now in maintenance.\n";
    }
}

// ذخیره در فایل
void FleetManager::saveCars() {
    ofstream outFile(filePath);
    Car* temp = head;
    while (temp) {
        outFile << temp->model << " " << temp->pricePerDay << " " << (int)temp->status << endl;
        temp = temp->next;
    }
    outFile.close();
}

// بارگذاری از فایل
void FleetManager::loadCars() {
    ifstream inFile(filePath);
    if (!inFile) return;
    string m; double p; int s;
    while (inFile >> m >> p >> s) {
        Car* newCar = new Car(m, p);
        newCar->status = static_cast<CarStatus>(s);
        if (!head) head = tail = newCar;
        else { tail->next = newCar; newCar->prev = tail; tail = newCar; }
        carIndex.insert(m, newCar);
    }
}

bool FleetManager::extendRental(string username, string carModel, int extraDays, UserManager& uManager) {
    Car* car = findCar(carModel);
    if (!car) {
        cout << "Car not found!" << endl;
        return false;
    }

    // ۱. شرط اصلی: خالی بودن صف انتظار (Priority Queue)
    if (!car->waitList.isEmpty()) {
        cout << "Cannot extend! Other customers are waiting in the queue for this car." << endl;
        return false;
    }

    // ۲. پیدا کردن رزرو/اجاره فعال کاربر
    Reservation* temp = resHead;
    bool found = false;
    while (temp) {
        if (temp->username == username && temp->carModel == carModel && temp->isActive) {
            
            // ۳. محاسبه و اعمال هزینه جدید
            double extensionCost = extraDays * car->pricePerDay;
            User* user = uManager.findUser(username);
            if (user) {
                user->balance_due += extensionCost;
                uManager.saveToFile(); // ذخیره تراز مالی جدید کاربر
            }

            // ۴. تمدید تاریخ پایان (endDate)
            temp->endDate.day += extraDays;
            
            // اصلاح سرریز روزها (فرض هر ماه ۳۰ روز برای سادگی)
            while (temp->endDate.day > 30) {
                temp->endDate.day -= 30;
                temp->endDate.month++;
            }
            while (temp->endDate.month > 12) {
                temp->endDate.month -= 12;
                temp->endDate.year++;
            }

            cout << "--------------------------------------" << endl;
            cout << "Rental Extended Successfully!" << endl;
            cout << "Cost added: " << extensionCost << " Toman." << endl;
            cout << "New Return Date: " << temp->endDate.day << "/" << temp->endDate.month << "/" << temp->endDate.year << endl;
            cout << "--------------------------------------" << endl;
            
            found = true;
            break;
        }
        temp = temp->next;
    }

    if (!found) {
        cout << "You don't have an active rental for this car model!" << endl;
    }
    
    return found;
}

// خروجی درآمد به CSV
void FleetManager::exportRevenueCSV() {
    ofstream csvFile("revenue_report.csv");
    csvFile << "Total Earnings," << totalRevenue << endl;
    csvFile.close();
    cout << "Revenue report exported.\n";
}
void FleetManager::returnCar(string username, string carModel, Date actualDate, UserManager& uManager) {
    // اگر این متد را ننوشته بودی، کد زیر را استفاده کن:
    Car* car = findCar(carModel);
    if (!car || car->status != RENTED) return;

    Date dueDate = getReturnDate(carModel); 
    if (actualDate > dueDate) {
        int delay = actualDate.toDays() - dueDate.toDays();
        uManager.applyFine(username, delay * 50.0); // فرض جریمه ۵۰ تومانی
    }
    car->status = AVAILABLE;
    saveCars();
    processQueue(carModel);
}