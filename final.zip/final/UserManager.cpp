#include "UserManager.h"
#include <iostream>
#include <fstream>

using namespace std;

UserManager::UserManager(string path) : filePath(path), head(nullptr) {
    loadFromFile();
}

string UserManager::hashPassword(string password) {
    unsigned long hash = 5381; 
    for (char c : password) {
        
        hash = ((hash << 5) + hash) + c;
    }
    
    return to_string(hash);
}

bool UserManager::signUp(string username, string password, string role) {
    if (findUser(username)) {
        return false; 
    }
    
    
    string h_pass = hashPassword(password);
    User* newUser = new User(username, h_pass, role);
    
    
    newUser->next = head;
    head = newUser;
    
    
    userHash.insert(username, newUser);
    
    saveToFile();
    return true;
}

User* UserManager::login(string username, string password) {
    User* user = findUser(username);
    
    if (user && user->passwordHash == hashPassword(password)) {
        return user;
    }
    return nullptr;
}

User* UserManager::findUser(string username) {
    return userHash.search(username); 
}

void UserManager::applyFine(string username, double amount) {
    User* u = findUser(username);
    if (u) {
        u->balance_due += amount;
        saveToFile();
        cout << "Fine of " << amount << " applied to " << username << ". New balance: " << u->balance_due << endl;
    } else {
        cout << "User not found." << endl;
    }
}

void UserManager::toggleBlockStatus(string username) {
    User* u = findUser(username);
    if (u) {
        u->isBlocked = !u->isBlocked;
        saveToFile();
        cout << "User " << username << (u->isBlocked ? " is now BLOCKED." : " is now UNBLOCKED.") << endl;
    } else {
        cout << "User not found." << endl;
    }
}

void UserManager::saveToFile() {
    ofstream out(filePath);
    if (!out) return;

    User* temp = head;
    while (temp) {
        
        out << temp->username << " " 
            << temp->passwordHash << " " 
            << temp->role << " " 
            << temp->balance_due << " " 
            << (temp->isBlocked ? 1 : 0) << endl;
        temp = temp->next;
    }
    out.close();
}

void UserManager::loadFromFile() {
    ifstream in(filePath);
    if (!in) return;

    string un, pw, r;
    double bal;
    int blocked;

    while (in >> un >> pw >> r >> bal >> blocked) {
        User* newUser = new User(un, pw, r);
        newUser->balance_due = bal;
        newUser->isBlocked = (blocked == 1);
        
        
        newUser->next = head;
        head = newUser;
        userHash.insert(un, newUser);
    }
    in.close();
}
UserManager::~UserManager() {
    User* current = head;
    while (current) {
        User* next = current->next;
        delete current;
        current = next;
    }
}
void UserManager::payFine(string username, double amount) {
    User* u = findUser(username);
    if (u) {
        if (amount <= 0) {
            cout << "Error: Invalid payment amount.\n";
            return;
        }
        u->balance_due -= amount;
        if (u->balance_due < 0) u->balance_due = 0; 
        
        saveToFile();
        cout << "Payment successful! New balance: $" << u->balance_due << endl;
    } else {
        cout << "User not found.\n";
    }
}