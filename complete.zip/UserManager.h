#ifndef USER_MANAGER_H
#define USER_MANAGER_H

#include "User.h"
#include "HashTable.h"
#include <string>

using namespace std;

class UserManager {
private:
    User* head;
    string filePath;
    HashTable userHash;
    string hashPassword(string password); 

public:
    UserManager(string path);
    void saveToFile();
    void loadFromFile();
    bool signUp(string username, string password, string role);
    User* findUser(string username);
    User* login(string username, string password);
    void applyFine(string username, double amount);
    void toggleBlockStatus(string username);
    void payFine(string username, double amount);
    void showDefaulters();
    ~UserManager();
};

#endif