#include "AVLTree.h"

int AVLTree::height(AVLNode* n) { return n ? n->height : 0; }

int AVLTree::getBalance(AVLNode* n) { return n ? height(n->left) - height(n->right) : 0; }

AVLNode* AVLTree::rightRotate(AVLNode* y) {
    AVLNode* x = y->left;
    AVLNode* T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;
    return x;
}

AVLNode* AVLTree::leftRotate(AVLNode* x) {
    AVLNode* y = x->right;
    AVLNode* T2 = y->left;
    y->left = x;
    x->right = T2;
    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;
    return y;
}

AVLNode* AVLTree::insert(AVLNode* node, string key, Car* ptr) {
    if (!node) return new AVLNode(key, ptr);
    if (key < node->key) node->left = insert(node->left, key, ptr);
    else if (key > node->key) node->right = insert(node->right, key, ptr);
    else return node;

    node->height = 1 + max(height(node->left), height(node->right));
    int balance = getBalance(node);

    if (balance > 1 && key < node->left->key) return rightRotate(node);
    if (balance < -1 && key > node->right->key) return leftRotate(node);
    if (balance > 1 && key > node->left->key) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }
    if (balance < -1 && key < node->right->key) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }
    return node;
}

Car* AVLTree::search(AVLNode* root, string key) {
    if (!root || root->key == key) return root ? root->carPtr : nullptr;
    if (root->key < key) return search(root->right, key);
    return search(root->left, key);
}