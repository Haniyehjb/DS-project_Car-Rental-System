#ifndef DATE_H
#define DATE_H

#include <iostream>
using namespace std;

struct Date {
    int day, month, year;

    Date(int d = 0, int m = 0, int y = 0) : day(d), month(m), year(y) {
        normalize(); // اصلاح خودکار در صورت وارد کردن اعداد نامعتبر
    }

    // تبدیل تاریخ به عدد کل روزها
    int toDays() const {
        return year * 365 + month * 30 + day; 
    }

    // متد کمکی برای تمدید تاریخ
    void addDays(int days) {
        day += days;
        normalize();
    }

    // اصلاح ساختار تاریخ (مثلاً تبدیل ۳۲ روز به ۱ ماه و ۲ روز)
    void normalize() {
        while (day > 30) {
            day -= 30;
            month++;
        }
        while (month > 12) {
            month -= 12;
            year++;
        }
    }

    bool operator<(const Date& other) const { return toDays() < other.toDays(); }
    bool operator>(const Date& other) const { return toDays() > other.toDays(); }
    bool operator<=(const Date& other) const { return toDays() <= other.toDays(); }
    bool operator>=(const Date& other) const { return toDays() >= other.toDays(); }
    
    // چاپ راحت تاریخ
    void print() const {
        cout << year << "/" << (month < 10 ? "0" : "") << month << "/" << (day < 10 ? "0" : "") << day;
    }
};

#endif