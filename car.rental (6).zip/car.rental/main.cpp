#include <iostream>
#include <string>
#include "UserManager.h"
#include "FleetManager.h"
#include "Date.h"

using namespace std;

const string USER_FILE = "users.txt";
const string CAR_FILE = "cars.txt";

// --- منوی مدیریت (مدیر سیستم) ---
void showManagerMenu(UserManager& uManager, FleetManager& fManager) {
    int choice;
    while (true) {
        cout << "\n--- MANAGER PANEL ---\n";
        cout << "1. Add New Car\n";
        cout << "2. Set Maintenance Status\n";
        cout << "3. Process Car Waitlist\n";
        cout << "4. Export Revenue Report (CSV)\n";
        cout << "5. View Defaulters (Debt > 1000)\n";
        cout << "6. Logout\n";
        cout << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            string m; double p;
            cout << "Model: "; cin >> m;
            cout << "Price/Day: "; cin >> p;
            fManager.addCar(m, p);
        } else if (choice == 2) {
            string m; cout << "Model: "; cin >> m;
            fManager.setMaintenance(m);
        } else if (choice == 3) {
            string m; cout << "Model to process: "; cin >> m;
            fManager.processQueue(m);
        } else if (choice == 4) {
            fManager.exportRevenueCSV();
            cout << "Report exported to revenue.csv\n";
        } else if (choice == 5) {
            uManager.showDefaulters();
        } else if (choice == 6) break;
    }
}

// --- منوی مشتری ---
void showCustomerMenu(User* user, UserManager& manager, FleetManager& fleet) {
    int choice;
    while (true) {
        cout << "\n--- CUSTOMER MENU (" << user->username << ") ---\n";
        cout << "1. View Cars & Availability\n";
        cout << "2. Reserve / Rent a Car\n";
        cout << "3. Extend Current Rental (No Waitlist only)\n";
        cout << "4. Return Car & Finalize Fines\n";
        cout << "5. View My History & Balance\n";
        cout << "6. Pay Fines\n";
        cout << "7. Logout\n";
        cout << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            fleet.displayAllCars();
        } 
        else if (choice == 2) {
            if (user->balance_due > 1000) {
                cout << "\n[!] ACCESS DENIED: Please pay your debt (" << user->balance_due << ") first.\n";
                continue;
            }

            string model;
            cout << "\nEnter car model: "; cin >> model;
            Car* car = fleet.findCar(model);
            if (!car) { cout << "Car not found!\n"; continue; }

            if (car->status != AVAILABLE) {
                cout << "Car is busy. Join waitlist? (y/n): ";
                char join; cin >> join;
                if (join == 'y' || join == 'Y') {
                    car->waitList.push(user->username, 1);
                    cout << "Added to waitlist.\n";
                }
            } else {
                int d, m, y;
                cout << "Start Date (d m y): "; cin >> d >> m >> y;
                Date start(d, m, y);
                cout << "End Date (d m y): "; cin >> d >> m >> y;
                Date end(d, m, y);

                int days = end.toDays() - start.toDays() + 1;
                if (days <= 0) days = 1;
                double totalCost = days * car->pricePerDay;

                cout << "Total Cost: " << totalCost << " Toman. Confirm? (y/n): ";
                char confirm; cin >> confirm;
                if (confirm == 'y' || confirm == 'Y') {
                    if (fleet.addReservation(user->username, model, start, end)) {
                        user->balance_due += totalCost;
                        if (user->history == "No_History") user->history = model;
                        else user->history += "," + model;
                        manager.saveToFile();
                        cout << "Reservation successful!\n";
                    }
                }
            }
        }
        else if (choice == 3) {
            // تمدید اجاره
            string model; int days;
            cout << "Enter car model to extend: "; cin >> model;
            cout << "Enter extra days: "; cin >> days;
            // فراخوانی متد جدید تمدید
            fleet.extendRental(user->username, model, days, manager);
        }
        else if (choice == 4) {
            // بازگشت خودرو
            string model; int d, m, y;
            cout << "Enter car model to return: "; cin >> model;
            cout << "Enter current date (d m y): "; cin >> d >> m >> y;
            Date actualDate(d, m, y);
            // فراخوانی متد بازگشت خودرو (جریمه را حساب و ماشین را آزاد می‌کند)
            fleet.returnCar(user->username, model, actualDate, manager);
        }
        else if (choice == 5) {
            cout << "\n--- PROFILE ---\nDebt: " << user->balance_due << "\nHistory: " << user->history << endl;
        }
        else if (choice == 6) {
            if (user->balance_due <= 0) { cout << "No debt to pay.\n"; continue; }
            double amount;
            cout << "Enter amount to pay: "; cin >> amount;
            if (amount > user->balance_due) amount = user->balance_due;
            user->balance_due -= amount;
            manager.saveToFile();
            cout << "Payment successful. Remaining: " << user->balance_due << endl;
        }
        else if (choice == 7) break;
    }
}

int main() {
    UserManager system(USER_FILE);
    FleetManager fleet(CAR_FILE);
    int choice;
    string u, p;

    while (true) {
        cout << "\n--- CAR RENTAL SYSTEM ---\n1. Sign Up\n2. Customer Login\n3. Admin Login\n4. Exit\nChoice: ";
        cin >> choice;
        
        if (choice == 1) {
            cout << "Username: "; cin >> u;
            cout << "Password: "; cin >> p;
            system.signUp(u, p, "Customer");
        } 
        else if (choice == 2) {
            cout << "Username: "; cin >> u;
            cout << "Password: "; cin >> p;
            User* loggedIn = system.login(u, p);
            if (loggedIn) showCustomerMenu(loggedIn, system, fleet);
            else cout << "Login failed!\n";
        } 
        else if (choice == 3) {
            cout << "Admin: "; cin >> u;
            cout << "Pass: "; cin >> p;
            if (u == "admin" && p == "admin123") showManagerMenu(system, fleet);
            else cout << "Access denied.\n";
        } 
        else if (choice == 4) break;
    }
    return 0;
}