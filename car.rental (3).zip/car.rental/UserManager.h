#ifndef USER_MANAGER_H
#define USER_MANAGER_H

#include "User.h"
#include "HashTable.h" // استفاده از کلاس جداگانه‌ای که برای هش نوشتیم
#include <string>

using namespace std;

class UserManager {
private:
    User* head;            // برای نگهداری لیست پیوندی کاربران (الزام صورت‌مسئله)
    string filePath;       // مسیر فایل کاربران
    HashTable userHash;    // شیء جدول هش برای جستجوی سریع O(1)

public:
    UserManager(string path);
    
    // متدهای مربوط به مدیریت فایل و نمایش
    void showDefaulters();
    void saveToFile();
    void loadFromFile();
    
    // متدهای اصلی سیستم
    bool signUp(string username, string password, string role);
    User* findUser(string username);
    User* login(string username, string password);
    void applyFine(string username, double amount);
};

#endif