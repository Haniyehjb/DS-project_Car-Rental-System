#include "FleetManager.h"
#include <iostream>
#include <fstream>

using namespace std;

FleetManager::FleetManager(string path) : filePath(path) {
    head = tail = nullptr;
    resHead = nullptr;
    totalRevenue = 0.0;
    loadCars();
}

void FleetManager::addCar(string model, double price) {
    Car* newCar = new Car(model, price);
    if (!head) {
        head = tail = newCar;
    } else {
        tail->next = newCar;
        newCar->prev = tail;
        tail = newCar;
    }
    carIndex.insert(model, newCar); 
    saveCars();
}

Car* FleetManager::findCar(string model) {
    return carIndex.search(model);
}

bool FleetManager::isCarAvailable(string model, Date start, Date end) {
    Car* c = findCar(model);
    if (!c || c->status == MAINTENANCE) return false;

    Reservation* temp = resHead;
    while (temp) {
        if (temp->carModel == model && temp->isActive) {
            if (!(end < temp->startDate || start > temp->endDate)) {
                return false; 
            }
        }
        temp = temp->next;
    }
    return true;
}

bool FleetManager::addReservation(string user, string carModel, Date start, Date end) {
    if (!isCarAvailable(carModel, start, end)) return false;

    Car* c = findCar(carModel);
    if (c) {
        c->status = RENTED; 
        
        int days = end.toDays() - start.toDays() + 1;
        if (days <= 0) days = 1;
        
        double cost = days * c->pricePerDay; // محاسبه هزینه این رزرو
        totalRevenue += cost;
        
        // ایجاد رزرو جدید
        Reservation* newRes = new Reservation(user, carModel, start, end);
        newRes->next = resHead;
        resHead = newRes;
        
        saveCars(); 
        return true; 
    }
    return false;
}

void FleetManager::processQueue(string model) {
    Car* c = findCar(model);
    if (c && !c->waitList.isEmpty()) {
        string nextUser = c->waitList.pop();
        cout << "Car " << model << " is now assigned to: " << nextUser << " from waitlist.\n";
    } else {
        cout << "Waitlist is empty for this car.\n";
    }
}

void FleetManager::setMaintenance(string model) {
    Car* target = findCar(model);
    if (target) {
        target->status = MAINTENANCE; 
        saveCars();
        cout << "Status: Maintenance.\n";
    }
}

void FleetManager::saveCars() {
    ofstream outFile(filePath);
    Car* temp = head;
    while (temp) {
        outFile << temp->model << " " << temp->pricePerDay << " " << (int)temp->status << endl;
        temp = temp->next;
    }
    outFile.close();
}

void FleetManager::loadCars() {
    ifstream inFile(filePath);
    if (!inFile) return;
    string m; double p; int s;
    while (inFile >> m >> p >> s) {
        Car* newCar = new Car(m, p);
        newCar->status = static_cast<CarStatus>(s);
        if (!head) head = tail = newCar;
        else { tail->next = newCar; newCar->prev = tail; tail = newCar; }
        carIndex.insert(m, newCar);
    }
}

void FleetManager::exportRevenueCSV() {
    ofstream csvFile("revenue_report.csv");
    csvFile << "Total Revenue Report\n";
    csvFile << "Total Earnings: " << totalRevenue << endl;
    csvFile.close();
    cout << "Report exported to revenue_report.csv\n";
}

void FleetManager::displayAllCars() {
    Car* temp = head;
    cout << "\n--- SHOWROOM FLEET LIST ---\n";
    cout << "Model\t\tPrice/Day\tStatus\n";
    cout << "------------------------------------------------\n";
    
    while (temp != nullptr) {
        cout << temp->model << "\t\t" << temp->pricePerDay << "\t\t";
        
        if (temp->status == AVAILABLE) cout << "[Available]";
        else if (temp->status == RENTED) cout << "[Rented]";
        else if (temp->status == MAINTENANCE) cout << "[In Maintenance]";
        
        cout << endl;
        temp = temp->next;
    }
    cout << "------------------------------------------------\n";
}