#ifndef CONSOLE_HELPER_H
#define CONSOLE_HELPER_H

#include <iostream>
#include <string>

#ifdef _WIN32
    #ifndef NOMINMAX
        #define NOMINMAX
    #endif
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #include <windows.h>
    #include <conio.h> // _getch
#else
    #include <termios.h>
    #include <unistd.h>
#endif


inline std::string getHiddenPassword() {
    std::string password = "";
    char ch;

#ifdef _WIN32
    
    while (true) {
        ch = _getch(); 
        if (ch == '\r' || ch == '\n') { 
            break;
        } 
        else if (ch == '\b') { 
            if (!password.empty()) {
                password.pop_back();
                std::cout << "\b \b"; 
            }
        } 
        else if (ch >= 32 && ch <= 126) { 
            password += ch;
            std::cout << '*'; 
        }
    }
#else
    
    struct termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    while ((ch = getchar()) != '\n') {
        if (ch == 127 || ch == 8) {
            if (!password.empty()) {
                password.pop_back();
                std::cout << "\b \b";
            }
        } else {
            password += ch;
            std::cout << '*';
        }
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
#endif

    std::cout << std::endl; 
    return password;
}

#endif