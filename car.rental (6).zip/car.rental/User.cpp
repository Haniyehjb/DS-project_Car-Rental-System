#include "User.h"

unsigned long long hashPassword(string str) {
    unsigned long long hash = 5381;
    for (char c : str) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

User::User(string un, string pw, string r) {
    username = un;
    passwordHash = hashPassword(pw);
    role = r;
    balance_due = 0.0;
    history = "No_History";
    next = nullptr;
}