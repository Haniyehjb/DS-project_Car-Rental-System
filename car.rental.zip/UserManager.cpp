#include "UserManager.h"
#include <iostream>
#include <fstream>

using namespace std;

UserManager::UserManager(string path) : filePath(path) {
    head = nullptr;
    for (int i = 0; i < HASH_TABLE_SIZE; i++) hashTable[i] = nullptr;
    loadFromFile();
}

int UserManager::getHash(string key) {
    int sum = 0;
    for (char c : key) sum += c;
    return sum % HASH_TABLE_SIZE;
}

void UserManager::showDefaulters() {
    User* temp = head;
    cout << "--- Users with Outstanding Debt ---\n";
    while (temp) {
        if (temp->balance_due > 0) {
            cout << "User: " << temp->username << " | Debt: " << temp->balance_due << endl;
        }
        temp = temp->next;
    }
}

void UserManager::saveToFile() {
    ofstream outFile(filePath);
    if (!outFile) return;
    User* temp = head;
    while (temp != nullptr) {
        outFile << temp->username << " " << temp->passwordHash << " " 
                << temp->role << " " << temp->balance_due << " " << temp->history << endl;
        temp = temp->next;
    }
    outFile.close();
}

void UserManager::loadFromFile() {
    ifstream inFile(filePath);
    if (!inFile) return;
    string un, r, hist;
    unsigned long long ph;
    double bal;
    while (inFile >> un >> ph >> r >> bal >> hist) {
        User* newUser = new User(un, "", r);
        newUser->passwordHash = ph;
        newUser->balance_due = bal;
        newUser->history = hist;
        newUser->next = head;
        head = newUser;
        hashTable[getHash(un)] = newUser;
    }
    inFile.close();
}

bool UserManager::signUp(string username, string password, string role) {
    if (findUser(username) != nullptr) {
        cout << "Error: Username exists!" << endl;
        return false;
    }
    User* newUser = new User(username, password, role);
    newUser->next = head;
    head = newUser;
    hashTable[getHash(username)] = newUser;
    saveToFile();
    return true;
}

User* UserManager::findUser(string username) {
    User* temp = head;
    while (temp != nullptr) {
        if (temp->username == username) return temp;
        temp = temp->next;
    }
    return nullptr;
}

User* UserManager::login(string username, string password) {
    User* user = findUser(username);
    if (user != nullptr && user->passwordHash == hashPassword(password)) {
        return user;
    }
    return nullptr;
}

void UserManager::applyFine(string username, double amount) {
    User* u = findUser(username);
    if (u) {
        u->balance_due += amount;
        saveToFile();
        cout << "Fine of " << amount << " applied to " << username << endl;
    }
}