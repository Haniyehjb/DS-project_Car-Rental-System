#ifndef PRIORITY_QUEUE_H
#define PRIORITY_QUEUE_H

#include <string>
#include <iostream>

using namespace std;

struct WaitRequest {
    string username;
    int priority; // زمان ثبت درخواست (عدد کمتر = اولویت بالاتر)

    WaitRequest() : username(""), priority(0) {} // سازنده پیش‌فرض برای آرایه
    WaitRequest(string u, int p) : username(u), priority(p) {}
};

class PriorityQueue {
private:
    WaitRequest* heap; // آرایه پویا به جای vector
    int capacity;      // ظرفیت کل آرایه
    int currentSize;   // تعداد عناصر فعلی

    // تابع برای دو برابر کردن ظرفیت آرایه در صورت پر شدن
    void resize() {
        capacity *= 2;
        WaitRequest* newHeap = new WaitRequest[capacity];
        for (int i = 0; i < currentSize; i++) {
            newHeap[i] = heap[i];
        }
        delete[] heap;
        heap = newHeap;
    }

    void heapifyUp(int index) {
        while (index > 0 && heap[index].priority < heap[(index - 1) / 2].priority) {
            // Swap دستی
            WaitRequest temp = heap[index];
            heap[index] = heap[(index - 1) / 2];
            heap[(index - 1) / 2] = temp;
            
            index = (index - 1) / 2;
        }
    }

    void heapifyDown(int index) {
        int smallest = index;
        int left = 2 * index + 1;
        int right = 2 * index + 2;

        if (left < currentSize && heap[left].priority < heap[smallest].priority)
            smallest = left;
        if (right < currentSize && heap[right].priority < heap[smallest].priority)
            smallest = right;

        if (smallest != index) {
            WaitRequest temp = heap[index];
            heap[index] = heap[smallest];
            heap[smallest] = temp;
            heapifyDown(smallest);
        }
    }

public:
    PriorityQueue() {
        capacity = 10;
        currentSize = 0;
        heap = new WaitRequest[capacity];
    }

    // بسیار مهم: آزاد کردن حافظه
    ~PriorityQueue() {
        delete[] heap;
    }

    void push(string user, int p) {
        if (currentSize == capacity) {
            resize();
        }
        heap[currentSize] = WaitRequest(user, p);
        heapifyUp(currentSize);
        currentSize++;
    }

    WaitRequest pop() {
        if (currentSize == 0) return WaitRequest("None", -1);
        
        WaitRequest root = heap[0];
        heap[0] = heap[currentSize - 1];
        currentSize--;
        heapifyDown(0);
        return root;
    }

    bool isEmpty() {
        return currentSize == 0;
    }
};

#endif