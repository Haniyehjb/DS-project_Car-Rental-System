#include <iostream>
#include <string>
#include <limits>
#include <cstdlib>
#include <conio.h> 

#include "UserManager.h"
#include "FleetManager.h"
#include "Date.h"
#include "ConsoleHelper.h" 

using namespace std; 


#define RESET          "\033[0m"
#define LIME_GREEN     "\033[92m"
#define MYSTERY_BLUE   "\033[94m"
#define ORANGE         "\033[38;5;208m"
#define WHITE          "\033[37m"
#define RED            "\033[31m"

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void pause() {
    cout << "\n" << WHITE << "Press Enter to continue..." << RESET;
    _getch(); 
}

void printLogo() {
    cout << LIME_GREEN << "================================================" << endl;
    cout << MYSTERY_BLUE << "  __  __ __  __  ___  _____  ____  ___  __  __ " << endl;
    cout << MYSTERY_BLUE << " |  \\/  |\\ \\/ / / __||_   _|| ___|| _ \\ \\ \\/ / " << endl;
    cout << MYSTERY_BLUE << " | |\\/| | \\  /  \\__ \\  | |  | __| |   <  \\  /  " << endl;
    cout << MYSTERY_BLUE << " |_|  |_|  |_|  |___/  |_|  |____||_|_\\  |_|   " << endl;
    cout << endl;
    cout << "        " << ORANGE << ">> Zoinks! Let's rent a ride! <<" << endl;
    cout << LIME_GREEN << "================================================" << RESET << endl << endl;
}

int getMenuChoice(string options[], int numOptions, string title) {
    int selected = 0;
    while (true) {
        clearScreen();
        printLogo();
        cout << WHITE << "   --- " << title << " ---" << RESET << endl << endl;

        for (int i = 0; i < numOptions; ++i) {
            if (i == selected)
                cout << ORANGE << " > " << options[i] << RESET << endl;
            else
                cout << WHITE << "   " << options[i] << RESET << endl;
        }

        int key = _getch();
        if (key == 0 || key == 224) { 
            key = _getch();
            if (key == 72) selected = (selected - 1 + numOptions) % numOptions;
            else if (key == 80) selected = (selected + 1) % numOptions;
        } else if (key == 13) { 
            return selected + 1;
        }
    }
}


void showManagerMenu(UserManager& uM, FleetManager& fM) {
    string options[] = {
        "1. Add New Car to Fleet", 
        "2. View All Active Rentals", 
        "3. Apply Manual Fine / Repair Cost", 
        "4. Block / Unblock User", 
        "5. Export Revenue Report (CSV)", 
        "6. Confirm Car Pickup (Set to RENTED)", 
        "7. Process Return (Health Check & Check-in)",
        "8. Logout"
    };
    int num = 8;

    while (true) {
        int choice = getMenuChoice(options, num, "ADMIN PANEL (STAFF)");

        if (choice == 1) {
            string m; double p;
            cout << "Enter Car Model: "; cin >> m;
            cout << "Enter Rental Price (per min): "; cin >> p;
            fM.addCar(m, p);
            pause();
        } else if (choice == 2) {
            fM.displayRentedCars();
            pause();
        } else if (choice == 3) {
            string u; double cost;
            cout << "Target Username: "; cin >> u;
            cout << "Fine/Repair Amount: "; cin >> cost;
            uM.applyFine(u, cost);
            pause();
        } else if (choice == 4) {
            string u; cout << "Username to Toggle: "; cin >> u;
            uM.toggleBlockStatus(u);
            pause();
        } else if (choice == 5) {
            fM.exportRevenueCSV();
            pause();
        } else if (choice == 6) {
            string m; cout << "Enter Car Model being picked up: "; cin >> m;
            fM.confirmPickup(m);
            pause();
        } else if (choice == 7) { 
            string m; 
            cout << "Enter Car Model being returned: "; cin >> m;
            Car* car = fM.findCar(m);
            if (car) {
                char health;
                cout << "Is the car healthy? (y/n): "; cin >> health;
                if (health == 'n' || health == 'N') {
                    car->status = MAINTENANCE; 
                    string u; double fine;
                    cout << "Car sent to MAINTENANCE.\nTarget Username for fine: "; cin >> u;
                    cout << "Enter Repair cost/Fine: $"; cin >> fine;
                    uM.applyFine(u, fine);
                    cout << ORANGE << "Fine of $" << fine << " added to " << u << "'s account." << RESET << endl;
                } else {
                    car->status = AVAILABLE; 
                    cout << LIME_GREEN << "Car is healthy and now AVAILABLE." << RESET << endl;
                }
                fM.saveToFile(); 
                uM.saveToFile();
            }
            pause();
        } else if (choice == 8) {
            break;
        }
    }
}


void showCustomerMenu(User* user, UserManager& uM, FleetManager& fM) {
    string options[] = {
        "1. View Fleet & Return Times",
        "2. Reserve a Car",
        "3. Return Car (Check-in)",
        "4. Pay Outstanding Balance",
        "5. Logout"
    };
    int num = 5;

    while (true) {
        string title = "WELCOME, " + user->username + " | Debt: $" + to_string((int)user->balance_due);
        int choice = getMenuChoice(options, num, title);

        if (choice == 1) {
            clearScreen();
            cout << WHITE << "--- CURRENT FLEET STATUS ---" << RESET << endl;
            fM.displayAllCars();
            cout << "\n" << ORANGE << "[Note: Cars marked as MAINTENANCE are currently unavailable]" << RESET << endl;
            pause();
        } else if (choice == 2) {
            if (user->balance_due > 1000) {
                cout << "\n[!] ACCESS DENIED: Debt too high.\n";
            } else {
                fM.displayAllCars();
                string model; 
                cout << "\nEnter Model to Reserve: "; cin >> model;
                Car* car = fM.findCar(model);
                if (!car) {
                    cout << "Error: Car not found.\n";
                } else if (car->status == MAINTENANCE) { 
                    cout << RED << "\n[!] SORRY: This car is in the repair shop (MAINTENANCE)." << RESET << endl;
                } else if (car->status != AVAILABLE) {
                    cout << "Car is busy. Join waitlist? (y/n): ";
                    char j; cin >> j;
                    if (j == 'y' || j == 'Y') car->waitList.push(user->username, 1);
                } else {
                    int s, e;
                    cout << "Start Minute: "; cin >> s;
                    cout << "End Minute: "; cin >> e;
                    if (fM.addReservation(user->username, model, Date(s), Date(e))) {
                        cout << "Reservation Successful!\n";
                    } else cout << "Time conflict!\n";
                }
            }
            pause();
        } else if (choice == 3) {
    string m; int curTime;
    cout << "Enter Car Model: "; cin >> m;
    cout << "Current Minute: "; cin >> curTime;
    
   
    fM.checkIn(m, Date(curTime), uM); 
    
   
    User* updated = uM.login(user->username, ""); 
    if(updated) user->balance_due = updated->balance_due;

    pause();
        } else if (choice == 4) {
                    if (user->balance_due <= 0) {
                        cout << LIME_GREEN << "\n[i] You have no outstanding balance. Enjoy your ride!" << RESET << endl;
                    } else {
                        double amt;
                        cout << WHITE << "Your current debt: " << ORANGE << "$" << user->balance_due << RESET << endl;
                        cout << "Enter amount to pay: "; cin >> amt;
                        if (amt <= 0) {
                            cout << "Invalid amount!\n";
                        } else {
                            uM.payFine(user->username, amt);
                            cout << LIME_GREEN << "Payment successful. Remaining debt: $" << user->balance_due << RESET << endl;
                        }
                    }
                    pause();
                } else if (choice == 5) {
                    break;
                }
            }
        }


int main() {
    UserManager uM("users.txt");
    FleetManager fM("cars.txt");
    
    string mainMenu[] = {"1. Sign Up", "2. User Login", "3. Admin Login", "4. Exit"};
    int numMain = 4;

    while (true) {
        int choice = getMenuChoice(mainMenu, numMain, "CAR RENTAL SYSTEM V2.0");

        if (choice == 1) {
            string u, p;
            cout << "Username: "; cin >> u;
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout << "Password : "; 
            p = getHiddenPassword();
            if (uM.signUp(u, p, "Customer")) cout << "Success!\n";
            else cout << "Username exists.\n";
            pause();
        } else if (choice == 2) {
            string u, p;
            cout << "Username: "; cin >> u;
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout << "Password: "; 
            p = getHiddenPassword();
            User* user = uM.login(u, p);
            if (user && !user->isBlocked) showCustomerMenu(user, uM, fM);
            else if (user) cout << "Account BLOCKED.\n";
            else cout << "Invalid Login.\n";
            if (!user || user->isBlocked) pause();
        } else if (choice == 3) {
            string u, p;
            cout << "Admin ID: "; cin >> u;
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cout << "Admin Password: "; 
            p = getHiddenPassword();
            if (u == "admin" && p == "admin123") showManagerMenu(uM, fM);
            else { cout << "Invalid Admin.\n"; pause(); }
        } else if (choice == 4) break;
    }
    return 0;
}