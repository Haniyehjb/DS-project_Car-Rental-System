#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

class User {
public:
    string username;
    string passwordHash;
    string role;
    double balance_due;
    string history;
    bool isBlocked;
    User* next;
    

    // سازنده (Constructor) با بدنه کامل
    User(string , string , string );
};

#endif