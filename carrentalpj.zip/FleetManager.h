#ifndef FLEET_MANAGER_H
#define FLEET_MANAGER_H

#include "Car.h"
#include "AVLTree.h"
#include "Reservation.h"
#include "User.h"
#include <string>

using namespace std;

class UserManager;

class FleetManager {
public:
    Car* head;
    Car* tail;
    AVLTree carIndex;
    Reservation* resHead; 
    double totalRevenue;
    string filePath;

    FleetManager(string path);
    void addCar(string model, double price);
    Car* findCar(string model);
    bool isCarAvailable(string model, Date start, Date end);
    bool addReservation(string user, string carModel, Date start, Date end);
    void processQueue(string model, Date startDate, int requestedDays);
    void displayRentedCars(); 
    void displayAllCars();
    void checkIn(string model, Date actualDate, UserManager& uManager);
    void saveReservations();
    void loadReservations(); 
    void saveCars();
    void loadCars();
    void exportRevenueCSV();
    void confirmPickup(string model);
    void saveToFile();
    bool extendRental(string username, string model, int extraDays);
    ~FleetManager();
};

#endif